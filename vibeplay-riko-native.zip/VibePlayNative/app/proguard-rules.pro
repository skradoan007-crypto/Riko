# Keep Hilt generated components
-keep class dagger.hilt.** { *; }
-keep class * extends dagger.hilt.android.lifecycle.HiltViewModel { *; }

# Room
-keep class androidx.room.** { *; }
-keep class com.rikodev.music.data.db.** { *; }

# Media3
-keep class androidx.media3.** { *; }

# Kotlin metadata / coroutines
-keepclassmembers class kotlinx.coroutines.** { volatile <fields>; }
-dontwarn org.jetbrains.annotations.**
