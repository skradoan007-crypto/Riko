package com.rikodev.music.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rikodev.music.ui.components.AmbientBackground
import com.rikodev.music.ui.theme.SweepColors
import com.rikodev.music.ui.theme.VibeTheme
import kotlinx.coroutines.delay

/**
 * Cinematic splash loader ported from app/index.tsx splash gate — a spinning neon
 * sweep ring, breathing wordmark and the "Enjoy Your Life Different" tagline, then it
 * hands off to the library.
 */
@Composable
fun SplashScreen(onDone: () -> Unit) {
    val colors = VibeTheme.colors
    val transition = rememberInfiniteTransition(label = "splash")
    val angle by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(2400, easing = LinearEasing), RepeatMode.Restart),
        label = "spin",
    )
    val breathe = remember { Animatable(0.92f) }
    LaunchedEffect(Unit) {
        breathe.animateTo(1.04f, animationSpec = infiniteRepeatable(tween(1100), RepeatMode.Reverse))
    }
    LaunchedEffect(Unit) {
        delay(1900)
        onDone()
    }

    AmbientBackground {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(168.dp)) {
                Canvas(modifier = Modifier.size(168.dp).rotate(angle)) {
                    drawArc(
                        brush = Brush.sweepGradient(SweepColors),
                        startAngle = 0f,
                        sweepAngle = 300f,
                        useCenter = false,
                        topLeft = Offset(8f, 8f),
                        size = androidx.compose.ui.geometry.Size(size.width - 16f, size.height - 16f),
                        style = Stroke(width = 14f, cap = StrokeCap.Round),
                    )
                }
                Text(
                    "♪",
                    fontSize = 54.sp,
                    color = colors.primary,
                    modifier = Modifier.scale(breathe.value),
                )
            }
            Text(
                "VibePlay – Riko",
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
                color = colors.onSurface,
                modifier = Modifier.scale(breathe.value),
            )
            Text(
                "Enjoy Your Life Different",
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = colors.accent,
                textAlign = TextAlign.Center,
                modifier = Modifier.alpha(0.9f),
            )
        }
    }
}
