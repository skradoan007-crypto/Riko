package com.rikodev.music.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rikodev.music.ui.theme.Radius
import com.rikodev.music.ui.theme.VibeTheme
import com.rikodev.music.ui.theme.vibeSpring

enum class GlassButtonVariant { PRIMARY, GLASS }

/**
 * Pill action button ported from components/GlassButton.tsx with the spring-press
 * (0.95) + haptic feedback and primary / glass variants.
 */
@Composable
fun GlassButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    variant: GlassButtonVariant = GlassButtonVariant.PRIMARY,
    leading: (@Composable () -> Unit)? = null,
    enabled: Boolean = true,
) {
    val colors = VibeTheme.colors
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val haptics = LocalHapticFeedback.current
    val scale by animateFloatAsState(if (pressed) 0.95f else 1f, vibeSpring(), label = "btn")
    val shape = RoundedCornerShape(Radius.pill)

    val bg = when (variant) {
        GlassButtonVariant.PRIMARY -> Brush.horizontalGradient(listOf(colors.primary, colors.accent))
        GlassButtonVariant.GLASS -> Brush.verticalGradient(listOf(colors.glassFillLight, colors.glassFillMid))
    }
    val fg = if (variant == GlassButtonVariant.PRIMARY) Color.White else colors.onSurface

    Row(
        modifier = modifier
            .scale(scale)
            .clip(shape)
            .background(bg)
            .then(
                if (variant == GlassButtonVariant.GLASS)
                    Modifier.border(BorderStroke(1.dp, colors.glassBorder), shape) else Modifier,
            )
            .clickable(interactionSource = interaction, indication = null, enabled = enabled) {
                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                onClick()
            }
            .padding(horizontal = 22.dp, vertical = 13.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        leading?.invoke()
        Text(text, color = fg, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
    }
}
