package com.rikodev.music.data.repo

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import com.rikodev.music.data.model.Track
import com.rikodev.music.feature.metadata.parseFromFilename
import com.rikodev.music.feature.metadata.stripExtension
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * MODE 1 — Browse + Pick. Ephemeral folder/file selection via the Storage Access
 * Framework (no MediaStore, no persistence). Ported from browseStore. Mirrors the
 * Expo DocumentPicker flow but uses real SAF DocumentFile traversal so an entire
 * picked folder's audio files become a playable, in-memory queue.
 */
@Singleton
class BrowseRepository @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val audioExt = listOf(".mp3", ".m4a", ".aac", ".flac", ".wav", ".ogg", ".opus", ".wma", ".aiff", ".alac")

    /** Build an ephemeral track list from a SAF tree (folder) uri. */
    suspend fun tracksFromFolder(treeUri: Uri): List<Track> = withContext(Dispatchers.IO) {
        val root = DocumentFile.fromTreeUri(context, treeUri) ?: return@withContext emptyList()
        val out = ArrayList<Track>()
        traverse(root, out)
        out.sortedBy { it.title.lowercase() }
    }

    private fun traverse(dir: DocumentFile, out: MutableList<Track>) {
        for (child in dir.listFiles()) {
            if (child.isDirectory) {
                traverse(child, out)
            } else if (child.isFile) {
                val name = child.name ?: continue
                if (!isAudio(name)) continue
                out.add(toTrack(child.uri, name, child.length(), dir.name ?: ""))
            }
        }
    }

    /** Build ephemeral tracks from individually picked document uris. */
    suspend fun tracksFromFiles(uris: List<Uri>): List<Track> = withContext(Dispatchers.IO) {
        uris.mapNotNull { uri ->
            val (name, size) = queryNameSize(uri) ?: return@mapNotNull null
            if (!isAudio(name)) return@mapNotNull null
            toTrack(uri, name, size, folderNameOf(uri))
        }
    }

    private fun isAudio(name: String): Boolean = audioExt.any { name.lowercase().endsWith(it) }

    private fun toTrack(uri: Uri, fileName: String, size: Long, folderName: String): Track {
        val parsed = parseFromFilename(fileName)
        return Track(
            id = "saf:" + uri.toString(),
            uri = uri.toString(),
            filename = fileName,
            title = parsed.title.ifBlank { stripExtension(fileName) },
            artist = parsed.artist ?: "Unknown Artist",
            album = "Unknown Album",
            albumArtist = parsed.artist,
            genre = null,
            mood = null,
            durationMs = 0L,
            trackNumber = parsed.trackNumber,
            year = null,
            folderPath = folderName,
            folderName = folderName.ifBlank { "Picked" },
            sizeBytes = size,
            dateAddedMs = System.currentTimeMillis(),
            artworkUri = null,
        )
    }

    private fun queryNameSize(uri: Uri): Pair<String, Long>? {
        context.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val nameIdx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIdx = c.getColumnIndex(OpenableColumns.SIZE)
                val name = if (nameIdx >= 0) c.getString(nameIdx) else uri.lastPathSegment ?: "audio"
                val size = if (sizeIdx >= 0 && !c.isNull(sizeIdx)) c.getLong(sizeIdx) else 0L
                return name to size
            }
        }
        return null
    }

    private fun folderNameOf(uri: Uri): String {
        val seg = uri.lastPathSegment ?: return "Picked"
        return seg.substringBeforeLast('/').substringAfterLast('/').ifBlank { "Picked" }
    }
}
