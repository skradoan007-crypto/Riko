package com.rikodev.music.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * VibePlay brand palette — ported 1:1 from the original "Light Neon Glass" theme
 * (theme/colors.ts). These values are the single source of brand identity.
 */
object Palette {
    val primary = Color(0xFF1565C0)
    val onPrimary = Color(0xFFFFFFFF)
    val primaryContainer = Color(0xFFD6E3FF)
    val secondary = Color(0xFF00A6FF)
    val tertiary = Color(0xFF7C4DFF)

    val accentCyan = Color(0xFF00E5FF)
    val accentMint = Color(0xFF1DE9B6)
    val accentPink = Color(0xFFFF4D8D)
    val accentAmber = Color(0xFFFFB300)
    val accentViolet = Color(0xFF8C5BFF)

    val background = Color(0xFFF5F9FF)
    val onBackground = Color(0xFF171C22)
    val surface = Color(0xFFFFFFFF)
    val surfaceAlt = Color(0xFFEAF2FE)
    val surfaceVariant = Color(0xFFDEE7F4)
    val onSurface = Color(0xFF171C22)
    val onSurfaceVariant = Color(0xFF434A54)
    val outline = Color(0xFF73798A)
    val outlineVariant = Color(0xFFC3CAD7)

    val error = Color(0xFFBA1A1A)
    val success = Color(0xFF2E7D32)
    val warning = Color(0xFFED6C02)

    val amoledBackground = Color(0xFF000000)
    val amoledSurface = Color(0xFF0A0E14)
    val amoledSurfaceVariant = Color(0xFF141A24)
    val amoledOnSurface = Color(0xFFE7ECF4)
}

/** Accent options exposed in Settings (ported from settings.tsx ACCENTS). */
val AccentChoices: List<Color> = listOf(
    Palette.primary,
    Palette.accentCyan,
    Palette.accentViolet,
    Palette.accentPink,
    Palette.accentMint,
    Palette.accentAmber,
)

/** Animated R color-sweep colors used by the splash loader. */
val SweepColors: List<Color> = listOf(
    Color(0xFF1565C0),
    Color(0xFF00E5FF),
    Color(0xFF1DE9B6),
    Color(0xFFFFB300),
    Color(0xFFFF4D8D),
    Color(0xFF8C5BFF),
    Color(0xFF1565C0),
)

/** Visualizer bar gradient colors. */
val BarColors: List<Color> = listOf(
    Color(0xFF00E5FF),
    Color(0xFF1565C0),
    Color(0xFF8C5BFF),
)
