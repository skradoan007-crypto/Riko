package com.rikodev.music.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.background
import androidx.compose.ui.layout.ContentScale
import com.rikodev.music.ui.theme.Radius
import com.rikodev.music.ui.theme.VibeTheme

/**
 * Frosted "glass" surface ported from components/GlassSurface.tsx: a translucent
 * fill, a hairline light border and a soft elevation glow. Compose can't do runtime
 * backdrop blur pre-API-31 cheaply, so we emulate the frosted look with layered
 * translucent fills + border, matching the original's appearance.
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = Radius.lg,
    elevation: Dp = 10.dp,
    accentBorder: Boolean = false,
    contentPadding: Dp = 16.dp,
    content: @Composable () -> Unit,
) {
    val colors = VibeTheme.colors
    val shape = RoundedCornerShape(cornerRadius)
    Box(
        modifier = modifier
            .shadow(elevation, shape, clip = false, ambientColor = colors.accent.copy(alpha = 0.25f), spotColor = colors.accent.copy(alpha = 0.25f))
            .clip(shape)
            .background(
                Brush.verticalGradient(listOf(colors.glassFillLight, colors.glassFillMid)),
            )
            .border(
                BorderStroke(1.dp, if (accentBorder) colors.glassBorderAccent else colors.glassBorder),
                shape,
            )
            .padding(contentPadding),
    ) {
        content()
    }
}
