package com.rikodev.music.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

/** Theme mode ported from settings/ThemeProvider (system | light | amoled). */
enum class ThemeMode { SYSTEM, LIGHT, AMOLED }

/**
 * Resolved theme bundle exposed to the UI tree. Carries brand colors, the active
 * accent, the glass tokens and whether AMOLED is active — mirrors useTheme() in RN.
 */
class VibeColors(
    val isAmoled: Boolean,
    val accent: Color,
    val background: Color,
    val surface: Color,
    val surfaceAlt: Color,
    val surfaceVariant: Color,
    val onSurface: Color,
    val onSurfaceVariant: Color,
    val outline: Color,
    val outlineVariant: Color,
    val primary: Color,
    val onPrimary: Color,
    val primaryContainer: Color,
    val error: Color,
    val accentPink: Color,
    val accentCyan: Color,
    val accentMint: Color,
    val accentAmber: Color,
    val accentViolet: Color,
    val glassFillLight: Color,
    val glassFillMid: Color,
    val glassFillFaint: Color,
    val glassBorder: Color,
    val glassBorderAccent: Color,
)

val LocalVibeColors = staticCompositionLocalOf<VibeColors> {
    error("VibeColors not provided")
}

/** Convenience accessor mirroring `const { theme } = useTheme()`. */
object VibeTheme {
    val colors: VibeColors
        @Composable get() = LocalVibeColors.current
}

private fun buildColors(amoled: Boolean, accent: Color): VibeColors = VibeColors(
    isAmoled = amoled,
    accent = accent,
    background = if (amoled) Palette.amoledBackground else Palette.background,
    surface = if (amoled) Palette.amoledSurface else Palette.surface,
    surfaceAlt = if (amoled) Palette.amoledSurfaceVariant else Palette.surfaceAlt,
    surfaceVariant = if (amoled) Palette.amoledSurfaceVariant else Palette.surfaceVariant,
    onSurface = if (amoled) Palette.amoledOnSurface else Palette.onSurface,
    onSurfaceVariant = if (amoled) Color(0xFFAAB3C2) else Palette.onSurfaceVariant,
    outline = Palette.outline,
    outlineVariant = if (amoled) Color(0xFF2A323E) else Palette.outlineVariant,
    primary = Palette.primary,
    onPrimary = Palette.onPrimary,
    primaryContainer = if (amoled) Color(0xFF15233B) else Palette.primaryContainer,
    error = Palette.error,
    accentPink = Palette.accentPink,
    accentCyan = Palette.accentCyan,
    accentMint = Palette.accentMint,
    accentAmber = Palette.accentAmber,
    accentViolet = Palette.accentViolet,
    glassFillLight = if (amoled) Glass.fillLightAmoled else Glass.fillLight,
    glassFillMid = if (amoled) Glass.fillMidAmoled else Glass.fillMid,
    glassFillFaint = if (amoled) Glass.fillFaintAmoled else Glass.fillFaint,
    glassBorder = if (amoled) Glass.borderLightAmoled else Glass.borderLight,
    glassBorderAccent = Glass.borderAccent,
)

@Composable
fun VibePlayTheme(
    mode: ThemeMode,
    accent: Color,
    content: @Composable () -> Unit,
) {
    val systemDark = isSystemInDarkTheme()
    val amoled = when (mode) {
        ThemeMode.AMOLED -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> systemDark
    }
    val vibe = buildColors(amoled, accent)

    val scheme = if (amoled) {
        darkColorScheme(
            primary = accent,
            onPrimary = vibe.onPrimary,
            background = vibe.background,
            onBackground = vibe.onSurface,
            surface = vibe.surface,
            onSurface = vibe.onSurface,
            surfaceVariant = vibe.surfaceVariant,
            onSurfaceVariant = vibe.onSurfaceVariant,
            error = vibe.error,
        )
    } else {
        lightColorScheme(
            primary = accent,
            onPrimary = vibe.onPrimary,
            background = vibe.background,
            onBackground = vibe.onSurface,
            surface = vibe.surface,
            onSurface = vibe.onSurface,
            surfaceVariant = vibe.surfaceVariant,
            onSurfaceVariant = vibe.onSurfaceVariant,
            error = vibe.error,
        )
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !amoled
                isAppearanceLightNavigationBars = !amoled
            }
        }
    }

    CompositionLocalProvider(LocalVibeColors provides vibe) {
        MaterialTheme(
            colorScheme = scheme,
            typography = VibeTypography,
            content = content,
        )
    }
}
