package com.rikodev.music.feature.shuffle

import com.rikodev.music.data.model.Track
import kotlin.math.max
import kotlin.random.Random

/**
 * Flagship Group Shuffle engine ported from features/shuffle/groupShuffle.
 * Groups tracks by a key, then orders both the groups and the songs within them
 * according to the chosen mode + tuning knobs. Returns the final order, a plan and
 * per-group scores so the UI can explain what happened.
 */
enum class GroupByKey { ARTIST, ALBUM, GENRE, FOLDER, YEAR, DECADE, MOOD, CUSTOM_TAG }

enum class GroupMode {
    SEQUENTIAL_GROUPS_RANDOM_SONGS,
    RANDOM_GROUPS_SEQUENTIAL_SONGS,
    RANDOM_GROUPS_RANDOM_SONGS,
    WEIGHTED,
    EQUAL_ROTATION,
    NO_REPEAT_GROUP,
}

data class GroupShuffleConfig(
    val groupBy: GroupByKey = GroupByKey.ARTIST,
    val mode: GroupMode = GroupMode.EQUAL_ROTATION,
    val minPerGroup: Int = 1,
    val maxConsecutive: Int = 1,
    val pinnedGroups: List<String> = emptyList(),
    val excludedGroups: List<String> = emptyList(),
    val preferUnderplayed: Boolean = true,
    val skipRecentGroups: Boolean = false,
    val diversity: Float = 0.6f,
    val customTag: String? = null,
)

val DEFAULT_GROUP_CONFIG = GroupShuffleConfig()

data class GroupScore(val key: String, val size: Int, val score: Double)

data class GroupShuffleResult(
    val order: List<Track>,
    val plan: List<String>,
    val groupScores: List<GroupScore>,
)

private fun keyOf(track: Track, by: GroupByKey, customTag: String?): String = when (by) {
    GroupByKey.ARTIST -> track.artist
    GroupByKey.ALBUM -> track.album
    GroupByKey.GENRE -> track.genre ?: "Unknown"
    GroupByKey.FOLDER -> track.folderName
    GroupByKey.YEAR -> track.year?.toString() ?: "Unknown"
    GroupByKey.DECADE -> track.year?.let { "${(it / 10) * 10}s" } ?: "Unknown"
    GroupByKey.MOOD -> track.mood ?: "Unknown"
    GroupByKey.CUSTOM_TAG -> customTag ?: "All"
}

fun generateGroupShuffle(
    tracks: List<Track>,
    config: GroupShuffleConfig,
    recentIds: List<String>,
): GroupShuffleResult {
    if (tracks.isEmpty()) return GroupShuffleResult(emptyList(), emptyList(), emptyList())
    val rng = Random.Default
    val recent = recentIds.toHashSet()

    // 1) Build groups, honoring exclusions.
    val grouped = LinkedHashMap<String, MutableList<Track>>()
    for (t in tracks) {
        val k = keyOf(t, config.groupBy, config.customTag)
        if (k in config.excludedGroups) continue
        grouped.getOrPut(k) { mutableListOf() }.add(t)
    }
    if (grouped.isEmpty()) return GroupShuffleResult(emptyList(), emptyList(), emptyList())

    // 2) Order songs within each group.
    fun orderSongs(songs: List<Track>): List<Track> = when (config.mode) {
        GroupMode.RANDOM_GROUPS_SEQUENTIAL_SONGS ->
            songs.sortedWith(compareBy({ it.trackNumber ?: Int.MAX_VALUE }, { it.title.lowercase() }))
        else -> {
            if (config.preferUnderplayed) {
                songs.map { s ->
                    var w = 1.0 / (1.0 + s.playCount)
                    if (s.id in recent) w *= 0.3
                    val key = -Math.log(max(rng.nextDouble(), 1e-12)) / max(w, 1e-6)
                    s to key
                }.sortedBy { it.second }.map { it.first }
            } else songs.shuffled(rng)
        }
    }
    val orderedGroups: Map<String, List<Track>> = grouped.mapValues { orderSongs(it.value) }

    // 3) Score + order the groups themselves.
    val scores = orderedGroups.map { (key, songs) ->
        var score = songs.size.toDouble()
        if (config.preferUnderplayed) {
            val avgPlays = songs.map { it.playCount }.average()
            score += 5.0 / (1.0 + avgPlays)
        }
        if (config.skipRecentGroups && songs.any { it.id in recent }) score *= 0.4
        if (key in config.pinnedGroups) score += 1000.0
        // diversity adds randomness to the ordering.
        score += rng.nextDouble() * (config.diversity * 10.0)
        GroupScore(key, songs.size, score)
    }

    val groupOrder: List<String> = when (config.mode) {
        GroupMode.SEQUENTIAL_GROUPS_RANDOM_SONGS ->
            scores.sortedByDescending { it.score }.map { it.key }
        GroupMode.WEIGHTED ->
            scores.map { gs ->
                val key = -Math.log(max(rng.nextDouble(), 1e-12)) / max(gs.score, 1e-6)
                gs.key to key
            }.sortedBy { it.second }.map { it.first }
        GroupMode.EQUAL_ROTATION, GroupMode.NO_REPEAT_GROUP, GroupMode.RANDOM_GROUPS_RANDOM_SONGS,
        GroupMode.RANDOM_GROUPS_SEQUENTIAL_SONGS ->
            scores.shuffled(rng).sortedByDescending { it.key in config.pinnedGroups }.map { it.key }
    }

    // 4) Emit interleaved order honoring minPerGroup / maxConsecutive.
    val queues = LinkedHashMap<String, ArrayDeque<Track>>()
    groupOrder.forEach { k -> orderedGroups[k]?.let { queues[k] = ArrayDeque(it) } }

    val out = ArrayList<Track>()
    val plan = ArrayList<String>()
    var lastKey: String? = null
    var consecutive = 0
    var remaining = queues.values.sumOf { it.size }

    val rotation = if (config.mode == GroupMode.SEQUENTIAL_GROUPS_RANDOM_SONGS) {
        // Drain each group fully in order.
        for (k in groupOrder) {
            val q = queues[k] ?: continue
            if (q.isEmpty()) continue
            plan.add("$k × ${q.size}")
            while (q.isNotEmpty()) out.add(q.removeFirst())
        }
        true
    } else false

    if (!rotation) {
        while (remaining > 0) {
            var progressed = false
            for (k in groupOrder) {
                val q = queues[k] ?: continue
                if (q.isEmpty()) continue
                if (k == lastKey && consecutive >= config.maxConsecutive && queues.values.count { it.isNotEmpty() } > 1) {
                    continue
                }
                val take = max(1, config.minPerGroup)
                var taken = 0
                while (q.isNotEmpty() && taken < take) {
                    out.add(q.removeFirst())
                    taken++
                    remaining--
                }
                if (taken > 0) {
                    plan.add("$k × $taken")
                    consecutive = if (k == lastKey) consecutive + 1 else 1
                    lastKey = k
                    progressed = true
                }
            }
            if (!progressed) {
                // Flush whatever remains to avoid an infinite loop.
                for (q in queues.values) while (q.isNotEmpty()) { out.add(q.removeFirst()); remaining-- }
            }
        }
    }

    return GroupShuffleResult(out, plan, scores.sortedByDescending { it.score })
}
