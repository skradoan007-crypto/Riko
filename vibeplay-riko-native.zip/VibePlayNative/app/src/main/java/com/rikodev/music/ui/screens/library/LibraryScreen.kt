package com.rikodev.music.ui.screens.library

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.rikodev.music.data.model.ScanPhase
import com.rikodev.music.ui.components.AmbientBackground
import com.rikodev.music.ui.components.GlassButton
import com.rikodev.music.ui.components.GlassButtonVariant
import com.rikodev.music.ui.components.TrackRow
import com.rikodev.music.ui.theme.VibeTheme

/**
 * MODE 2 — full folder scan Library. MediaStore-indexed, persistent, searchable, with
 * live scan progress, duplicate detection and the neon track list. Ported from
 * app/(tabs)/library.tsx.
 */
@Composable
fun LibraryScreen(
    onOpenNowPlaying: () -> Unit,
    viewModel: LibraryViewModel = hiltViewModel(),
) {
    val colors = VibeTheme.colors
    val ui by viewModel.uiState.collectAsStateWithLifecycle()
    val progress by viewModel.scanProgress.collectAsStateWithLifecycle()

    AmbientBackground {
        Column(modifier = Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column {
                    Text("Library", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = colors.onSurface)
                    Text(
                        "${ui.tracks.size} tracks" + if (ui.duplicates.isNotEmpty()) "  •  ${ui.duplicates.size} duplicate groups" else "",
                        fontSize = 13.sp,
                        color = colors.onSurfaceVariant,
                    )
                }
                GlassButton(
                    text = "Scan",
                    onClick = viewModel::rescan,
                    leading = { Icon(Icons.Filled.Refresh, contentDescription = null, tint = androidx.compose.ui.graphics.Color.White) },
                )
            }

            OutlinedTextField(
                value = ui.query,
                onValueChange = viewModel::setQuery,
                placeholder = { Text("Search title, artist, album, folder") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth(),
            )

            AnimatedVisibility(visible = progress.phase == ScanPhase.SCANNING || progress.phase == ScanPhase.INDEXING) {
                Column(modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) {
                    Text(
                        progress.message ?: "Scanning… ${progress.scanned}/${progress.total}",
                        fontSize = 12.sp,
                        color = colors.accent,
                        fontWeight = FontWeight.Medium,
                    )
                    LinearProgressIndicator(
                        progress = { if (progress.total > 0) progress.scanned.toFloat() / progress.total else 0f },
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                        color = colors.accent,
                        trackColor = colors.outlineVariant,
                    )
                }
            }

            if (ui.tracks.isEmpty()) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text("No tracks yet", color = colors.onSurface, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                    Text("Tap Scan to index your music library.", color = colors.onSurfaceVariant, fontSize = 13.sp)
                    GlassButton(
                        text = "Scan now",
                        onClick = viewModel::rescan,
                        variant = GlassButtonVariant.GLASS,
                        modifier = Modifier.padding(top = 14.dp),
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(top = 10.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 160.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    items(ui.tracks, key = { it.id }) { track ->
                        AnimatedVisibility(visible = true, enter = fadeIn() + slideInVertically { it / 4 }) {
                            TrackRow(
                                track = track,
                                isActive = false,
                                onClick = { viewModel.play(track); onOpenNowPlaying() },
                                onToggleFavorite = { viewModel.toggleFavorite(track) },
                            )
                        }
                    }
                }
            }
        }
    }
}
