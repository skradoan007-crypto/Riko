package com.rikodev.music.data.prefs

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import com.rikodev.music.feature.modify.DspState
import com.rikodev.music.feature.modify.EQ_FREQUENCIES
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import org.json.JSONArray
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

/** Persists the Modification Lab DSP state + master enable (ported from modifyStore). */
@Singleton
class ModifyRepository @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val store = context.vibeDataStore
    private val dspKey = stringPreferencesKey("dsp_json")
    private val enabledKey = booleanPreferencesKey("dsp_enabled")

    val dsp: Flow<DspState> = store.data.let { flow ->
        kotlinx.coroutines.flow.map(flow) { decode(it[dspKey]) }
    }
    val enabled: Flow<Boolean> = store.data.let { flow ->
        kotlinx.coroutines.flow.map(flow) { it[enabledKey] ?: true }
    }

    /** Combined state stream for convenience. */
    val state: Flow<Pair<DspState, Boolean>> = combine(dsp, enabled) { d, e -> d to e }

    suspend fun setDsp(state: DspState) = store.edit { it[dspKey] = encode(state) }
    suspend fun setEnabled(value: Boolean) = store.edit { it[enabledKey] = value }

    private fun encode(s: DspState): String = JSONObject().apply {
        put("bands", JSONArray(s.bands))
        put("bassBoost", s.bassBoost.toDouble())
        put("trebleBoost", s.trebleBoost.toDouble())
        put("vocal", s.vocal.toDouble())
        put("reverb", s.reverb.toDouble())
        put("echo", s.echo.toDouble())
        put("stereoWidth", s.stereoWidth.toDouble())
        put("preamp", s.preamp.toDouble())
        put("speed", s.speed.toDouble())
        put("pitch", s.pitch.toDouble())
    }.toString()

    private fun decode(raw: String?): DspState {
        if (raw.isNullOrEmpty()) return DspState()
        return runCatching {
            val o = JSONObject(raw)
            val arr = o.optJSONArray("bands")
            val bands = if (arr != null) {
                (0 until arr.length()).map { arr.getDouble(it).toFloat() }
            } else List(EQ_FREQUENCIES.size) { 0f }
            DspState(
                bands = bands,
                bassBoost = o.optDouble("bassBoost", 0.0).toFloat(),
                trebleBoost = o.optDouble("trebleBoost", 0.0).toFloat(),
                vocal = o.optDouble("vocal", 0.0).toFloat(),
                reverb = o.optDouble("reverb", 0.0).toFloat(),
                echo = o.optDouble("echo", 0.0).toFloat(),
                stereoWidth = o.optDouble("stereoWidth", 0.0).toFloat(),
                preamp = o.optDouble("preamp", 0.5).toFloat(),
                speed = o.optDouble("speed", 1.0).toFloat(),
                pitch = o.optDouble("pitch", 1.0).toFloat(),
            )
        }.getOrDefault(DspState())
    }
}
