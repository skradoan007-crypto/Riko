package com.rikodev.music.data.prefs

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import com.rikodev.music.ui.theme.ThemeMode
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

/** All user settings ported from settings/ThemeProvider + settingsStore. */
data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val accentColor: Long = 0xFF1565C0L,
    val animationsEnabled: Boolean = true,
    val gesturesEnabled: Boolean = true,
    val autoRescanOnLaunch: Boolean = false,
    val excludeShortClips: Boolean = true,
    val minClipSeconds: Int = 30,
    val resumeOnLaunch: Boolean = true,
    val gaplessHint: Boolean = true,
    val defaultRate: Float = 1f,
)

@Singleton
class SettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val store = context.vibeDataStore

    private object Keys {
        val themeMode = stringPreferencesKey("themeMode")
        val accent = longPreferencesKey("accentColor")
        val animations = booleanPreferencesKey("animationsEnabled")
        val gestures = booleanPreferencesKey("gesturesEnabled")
        val autoRescan = booleanPreferencesKey("autoRescanOnLaunch")
        val excludeShort = booleanPreferencesKey("excludeShortClips")
        val minClip = intPreferencesKey("minClipSeconds")
        val resume = booleanPreferencesKey("resumeOnLaunch")
        val gapless = booleanPreferencesKey("gaplessHint")
        val rate = floatPreferencesKey("defaultRate")
    }

    val settings: Flow<AppSettings> = store.data.map { p ->
        AppSettings(
            themeMode = runCatching { ThemeMode.valueOf(p[Keys.themeMode] ?: "SYSTEM") }
                .getOrDefault(ThemeMode.SYSTEM),
            accentColor = p[Keys.accent] ?: 0xFF1565C0L,
            animationsEnabled = p[Keys.animations] ?: true,
            gesturesEnabled = p[Keys.gestures] ?: true,
            autoRescanOnLaunch = p[Keys.autoRescan] ?: false,
            excludeShortClips = p[Keys.excludeShort] ?: true,
            minClipSeconds = p[Keys.minClip] ?: 30,
            resumeOnLaunch = p[Keys.resume] ?: true,
            gaplessHint = p[Keys.gapless] ?: true,
            defaultRate = p[Keys.rate] ?: 1f,
        )
    }

    suspend fun setThemeMode(mode: ThemeMode) = store.edit { it[Keys.themeMode] = mode.name }
    suspend fun setAccent(color: Long) = store.edit { it[Keys.accent] = color }
    suspend fun setAnimations(v: Boolean) = store.edit { it[Keys.animations] = v }
    suspend fun setGestures(v: Boolean) = store.edit { it[Keys.gestures] = v }
    suspend fun setAutoRescan(v: Boolean) = store.edit { it[Keys.autoRescan] = v }
    suspend fun setExcludeShort(v: Boolean) = store.edit { it[Keys.excludeShort] = v }
    suspend fun setMinClip(v: Int) = store.edit { it[Keys.minClip] = v }
    suspend fun setResume(v: Boolean) = store.edit { it[Keys.resume] = v }
    suspend fun setGapless(v: Boolean) = store.edit { it[Keys.gapless] = v }
    suspend fun setDefaultRate(v: Float) = store.edit { it[Keys.rate] = v }
}
