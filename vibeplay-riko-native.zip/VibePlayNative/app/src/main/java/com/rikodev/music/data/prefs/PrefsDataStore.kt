package com.rikodev.music.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore

/** Single app-wide DataStore replacing the persisted zustand stores. */
val Context.vibeDataStore: DataStore<Preferences> by preferencesDataStore(name = "vibeplay_prefs")
