package com.rikodev.music.feature.search

import com.rikodev.music.data.model.Track

/** Library search ported from features/search/search.ts (title/artist/album/folder/filename). */
data class SearchResults(
    val tracks: List<Track>,
)

fun searchLibrary(tracks: List<Track>, rawQuery: String, cap: Int = 200): SearchResults {
    val q = rawQuery.trim().lowercase()
    if (q.isEmpty()) return SearchResults(tracks)
    val terms = q.split(Regex("\\s+")).filter { it.isNotBlank() }

    val matched = tracks.asSequence().filter { t ->
        val haystack = buildString {
            append(t.title.lowercase()); append(' ')
            append(t.artist.lowercase()); append(' ')
            append(t.album.lowercase()); append(' ')
            append(t.folderName.lowercase()); append(' ')
            append(t.filename.lowercase())
        }
        terms.all { haystack.contains(it) }
    }.take(cap).toList()

    return SearchResults(matched)
}
