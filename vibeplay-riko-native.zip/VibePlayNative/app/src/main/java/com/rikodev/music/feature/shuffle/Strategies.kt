package com.rikodev.music.feature.shuffle

import com.rikodev.music.data.model.Track
import kotlin.math.max
import kotlin.random.Random

/** Context passed to strategies (now + recently played ids), ported from shuffle/index.ts. */
data class ShuffleContext(
    val now: Long,
    val recentIds: List<String>,
)

data class ShuffleStrategy(
    val id: String,
    val name: String,
    val description: String,
    val run: (List<Track>, ShuffleContext) -> List<Track>,
)

// ---- helpers (ported from strategies/index.ts) ----

private fun <K> groupBy(tracks: List<Track>, key: (Track) -> K): LinkedHashMap<K, MutableList<Track>> {
    val map = LinkedHashMap<K, MutableList<Track>>()
    for (t in tracks) map.getOrPut(key(t)) { mutableListOf() }.add(t)
    return map
}

/** Round-robin interleave of grouped buckets. */
private fun interleave(groups: Collection<List<Track>>): List<Track> {
    val queues = groups.map { ArrayDeque(it) }
    val out = ArrayList<Track>()
    var remaining = queues.sumOf { it.size }
    while (remaining > 0) {
        for (q in queues) {
            if (q.isNotEmpty()) {
                out.add(q.removeFirst())
                remaining--
            }
        }
    }
    return out
}

private fun shuffled(tracks: List<Track>, rng: Random): List<Track> = tracks.shuffled(rng)

/** Weighted ordering: higher weight -> earlier. Uses the classic exponential key trick. */
private fun weightedOrder(tracks: List<Track>, rng: Random, weight: (Track) -> Double): List<Track> =
    tracks.map { t ->
        val w = max(weight(t), 1e-6)
        val key = -Math.log(max(rng.nextDouble(), 1e-12)) / w
        t to key
    }.sortedBy { it.second }.map { it.first }

private fun decadeOf(year: Int?): Int? = year?.let { (it / 10) * 10 }

val STRATEGIES: List<ShuffleStrategy> = listOf(
    ShuffleStrategy("true-random", "True Random", "Pure unbiased shuffle of every track.") { t, _ ->
        shuffled(t, Random.Default)
    },
    ShuffleStrategy("smart", "Smart Mix", "Balances freshness, low play-count and variety.") { t, ctx ->
        val recent = ctx.recentIds.toHashSet()
        weightedOrder(t, Random.Default) { tr ->
            var w = 1.0
            w *= 1.0 / (1.0 + tr.playCount)
            if (tr.id in recent) w *= 0.25
            if (tr.isFavorite) w *= 1.4
            w
        }
    },
    ShuffleStrategy("weighted", "Weighted Favorites", "Favorites and loved tracks surface more often.") { t, _ ->
        weightedOrder(t, Random.Default) { if (it.isFavorite) 3.0 else 1.0 }
    },
    ShuffleStrategy("least-played", "Least Played", "Prioritizes tracks you rarely hear.") { t, _ ->
        weightedOrder(t, Random.Default) { 1.0 / (1.0 + it.playCount) }
    },
    ShuffleStrategy("hidden-gems", "Hidden Gems", "Old additions with very few plays.") { t, ctx ->
        weightedOrder(t, Random.Default) { tr ->
            val ageDays = max(0.0, (ctx.now - tr.dateAddedMs) / 86_400_000.0)
            (ageDays + 1) / (1.0 + tr.playCount * tr.playCount)
        }
    },
    ShuffleStrategy("no-repeat", "No Repeat", "Avoids recently played tracks first.") { t, ctx ->
        val recent = ctx.recentIds.toHashSet()
        val fresh = t.filter { it.id !in recent }.shuffled()
        val rest = t.filter { it.id in recent }.shuffled()
        fresh + rest
    },
    ShuffleStrategy("mood", "Mood Flow", "Groups by mood, then flows between them.") { t, _ ->
        interleave(groupBy(t) { it.mood ?: "unknown" }.values.map { it.shuffled() })
    },
    ShuffleStrategy("genre", "Genre Blend", "Even rotation across genres.") { t, _ ->
        interleave(groupBy(t) { it.genre ?: "unknown" }.values.map { it.shuffled() })
    },
    ShuffleStrategy("artist-rotation", "Artist Rotation", "Rotates evenly so no artist repeats back-to-back.") { t, _ ->
        interleave(groupBy(t) { it.artist }.values.map { it.shuffled() })
    },
    ShuffleStrategy("year-decade", "Decades", "Cycles across decades of release.") { t, _ ->
        interleave(groupBy(t) { decadeOf(it.year) ?: -1 }.values.map { it.shuffled() })
    },
    ShuffleStrategy("recently-added", "Recently Added", "Newest additions, lightly shuffled.") { t, _ ->
        val sorted = t.sortedByDescending { it.dateAddedMs }
        weightedOrder(sorted, Random.Default) { 1.0 }.let { sorted }
            .mapIndexed { i, tr -> tr to (i + Random.nextDouble() * 3) }
            .sortedBy { it.second }.map { it.first }
    },
    ShuffleStrategy("time-based", "Time of Day", "Adapts energy to the current hour.") { t, ctx ->
        val hour = ((ctx.now / 3_600_000) % 24).toInt()
        val daytime = hour in 7..19
        weightedOrder(t, Random.Default) { tr ->
            val energetic = (tr.genre ?: "").lowercase().let {
                it.contains("rock") || it.contains("electro") || it.contains("dance") || it.contains("pop")
            }
            if (daytime == energetic) 2.0 else 1.0
        }
    },
)

fun applyStrategy(id: String, tracks: List<Track>, ctx: ShuffleContext): List<Track> {
    val strat = STRATEGIES.firstOrNull { it.id == id } ?: STRATEGIES.first()
    if (tracks.isEmpty()) return tracks
    return strat.run(tracks, ctx)
}
