package com.rikodev.music.ui.screens.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.rikodev.music.ui.components.AmbientBackground
import com.rikodev.music.ui.components.GlassButton
import com.rikodev.music.ui.components.GlassButtonVariant
import com.rikodev.music.ui.components.GlassSurface
import com.rikodev.music.ui.theme.AccentChoices
import com.rikodev.music.ui.theme.ThemeMode
import com.rikodev.music.ui.theme.VibeTheme

/**
 * Settings — theme segments, accent swatches, behavior switches and maintenance
 * actions. Ported from app/(tabs)/settings.tsx.
 */
@Composable
fun SettingsScreen(viewModel: SettingsViewModel = hiltViewModel()) {
    val colors = VibeTheme.colors
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    AmbientBackground {
        LazyColumn(
            modifier = Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 18.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 12.dp, bottom = 170.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item { Text("Settings", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = colors.onSurface) }

            item {
                GlassSurface(modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Appearance", fontWeight = FontWeight.SemiBold, color = colors.onSurface, fontSize = 15.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ThemeMode.values().forEach { mode ->
                                val selected = settings.themeMode == mode
                                Text(
                                    mode.name.lowercase().replaceFirstChar { it.uppercase() },
                                    color = if (selected) Color.White else colors.onSurface,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(999.dp))
                                        .background(if (selected) colors.primary else colors.surfaceVariant)
                                        .clickable { viewModel.setThemeMode(mode) }
                                        .padding(vertical = 10.dp),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                )
                            }
                        }
                        Text("Accent", fontWeight = FontWeight.Medium, color = colors.onSurfaceVariant, fontSize = 13.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            AccentChoices.forEach { choice ->
                                val value = choice.value.toLong()
                                val selected = settings.accentColor == value
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .background(choice)
                                        .border(
                                            width = if (selected) 3.dp else 0.dp,
                                            color = colors.onSurface,
                                            shape = CircleShape,
                                        )
                                        .clickable { viewModel.setAccent(value) },
                                )
                            }
                        }
                    }
                }
            }

            item {
                GlassSurface(modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Playback & Library", fontWeight = FontWeight.SemiBold, color = colors.onSurface, fontSize = 15.sp)
                        ToggleRow("Animations", settings.animationsEnabled, viewModel::setAnimations)
                        ToggleRow("Gesture controls", settings.gesturesEnabled, viewModel::setGestures)
                        ToggleRow("Auto-rescan on launch", settings.autoRescanOnLaunch, viewModel::setAutoRescan)
                        ToggleRow("Exclude short clips", settings.excludeShortClips, viewModel::setExcludeShort)
                        ToggleRow("Resume on launch", settings.resumeOnLaunch, viewModel::setResume)
                        ToggleRow("Gapless hint", settings.gaplessHint, viewModel::setGapless)
                    }
                }
            }

            item {
                GlassSurface(modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Maintenance", fontWeight = FontWeight.SemiBold, color = colors.onSurface, fontSize = 15.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            GlassButton(text = "Rescan library", onClick = viewModel::rescanLibrary)
                            GlassButton(text = "Clear history", onClick = viewModel::clearHistory, variant = GlassButtonVariant.GLASS)
                        }
                    }
                }
            }

            item {
                Text(
                    "VibePlay – Riko  •  v1.0.0\nEnjoy Your Life Different",
                    color = colors.onSurfaceVariant,
                    fontSize = 12.sp,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
            }
        }
    }
}

@Composable
private fun ToggleRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    val colors = VibeTheme.colors
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, color = colors.onSurface, fontSize = 14.sp)
        Switch(checked = value, onCheckedChange = onChange)
    }
}
