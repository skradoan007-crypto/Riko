package com.rikodev.music.ui.screens.shuffle

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rikodev.music.audio.PlayerController
import com.rikodev.music.data.model.Track
import com.rikodev.music.data.repo.LibraryRepository
import com.rikodev.music.feature.shuffle.DEFAULT_GROUP_CONFIG
import com.rikodev.music.feature.shuffle.GroupByKey
import com.rikodev.music.feature.shuffle.GroupShuffleConfig
import com.rikodev.music.feature.shuffle.GroupShuffleResult
import com.rikodev.music.feature.shuffle.STRATEGIES
import com.rikodev.music.feature.shuffle.ShuffleStrategy
import com.rikodev.music.feature.shuffle.generateGroupShuffle
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

/**
 * Advanced Shuffle Lab view model — exposes all 12 strategies and the flagship Group
 * Shuffle engine, wiring their output straight into the player queue.
 */
@HiltViewModel
class ShuffleViewModel @Inject constructor(
    private val libraryRepository: LibraryRepository,
    private val playerController: PlayerController,
) : ViewModel() {

    val strategies: List<ShuffleStrategy> = STRATEGIES

    val library: StateFlow<List<Track>> = libraryRepository.library
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _config = MutableStateFlow(DEFAULT_GROUP_CONFIG)
    val config: StateFlow<GroupShuffleConfig> = _config.asStateFlow()

    private val _lastPlan = MutableStateFlow<GroupShuffleResult?>(null)
    val lastPlan: StateFlow<GroupShuffleResult?> = _lastPlan.asStateFlow()

    fun setGroupBy(key: GroupByKey) { _config.value = _config.value.copy(groupBy = key) }

    fun applyStrategy(id: String) {
        val tracks = library.value
        if (tracks.isEmpty()) return
        playerController.setShuffleStrategy(id)
        playerController.applyShuffleOrder(
            com.rikodev.music.feature.shuffle.applyStrategy(
                id,
                tracks,
                com.rikodev.music.feature.shuffle.ShuffleContext(
                    now = System.currentTimeMillis(),
                    recentIds = emptyList(),
                ),
            ),
        )
    }

    fun startGroupShuffle() {
        val tracks = library.value
        if (tracks.isEmpty()) return
        val result = generateGroupShuffle(tracks, _config.value, recentIds = emptyList())
        _lastPlan.value = result
        playerController.applyShuffleOrder(result.order)
    }
}
