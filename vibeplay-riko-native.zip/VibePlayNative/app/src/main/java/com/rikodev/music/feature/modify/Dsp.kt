package com.rikodev.music.feature.modify

/**
 * DSP state ported from features/modify/dsp.ts. In the native build EVERY field is
 * really applied: bands/bass/treble/vocal/reverb via android.media.audiofx bound to
 * the ExoPlayer audio session, speed/pitch via ExoPlayer PlaybackParameters,
 * echo + stereoWidth via EnvironmentalReverb / Virtualizer. Nothing is mocked.
 */
val EQ_FREQUENCIES = intArrayOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)

data class DspState(
    val bands: List<Float> = List(EQ_FREQUENCIES.size) { 0f }, // dB, -12..+12
    val bassBoost: Float = 0f,      // 0..1
    val trebleBoost: Float = 0f,    // 0..1
    val vocal: Float = 0f,          // 0..1
    val reverb: Float = 0f,         // 0..1
    val echo: Float = 0f,           // 0..1
    val stereoWidth: Float = 0f,    // 0..1
    val preamp: Float = 0.5f,       // 0..1
    val speed: Float = 1f,          // 0.5..2
    val pitch: Float = 1f,          // 0.5..2
) {
    fun withBand(index: Int, value: Float): DspState {
        val next = bands.toMutableList()
        if (index in next.indices) next[index] = value.coerceIn(-12f, 12f)
        return copy(bands = next)
    }
}

data class EqPreset(
    val id: String,
    val name: String,
    val bands: List<Float>,
    val bassBoost: Float = 0f,
    val trebleBoost: Float = 0f,
    val vocal: Float = 0f,
)

/** Built-in presets ported 1:1 from features/modify/presets.ts. */
val BUILT_IN_PRESETS: List<EqPreset> = listOf(
    EqPreset("flat", "Flat", listOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f)),
    EqPreset("bass", "Bass", listOf(6f, 5f, 4f, 2f, 0f, 0f, 0f, 0f, 1f, 2f), bassBoost = 0.6f),
    EqPreset("treble", "Treble", listOf(0f, 0f, 0f, 0f, 0f, 1f, 2f, 4f, 5f, 6f), trebleBoost = 0.6f),
    EqPreset("vocal", "Vocal", listOf(-2f, -1f, 0f, 2f, 4f, 4f, 3f, 1f, 0f, -1f), vocal = 0.7f),
    EqPreset("electronic", "Electronic", listOf(5f, 4f, 1f, 0f, -1f, 1f, 2f, 3f, 4f, 5f), bassBoost = 0.4f),
    EqPreset("rock", "Rock", listOf(4f, 3f, 2f, 0f, -1f, 0f, 2f, 3f, 4f, 4f)),
    EqPreset("acoustic", "Acoustic", listOf(3f, 2f, 1f, 0f, 1f, 2f, 2f, 3f, 2f, 1f), vocal = 0.3f),
    EqPreset("night", "Night", listOf(2f, 1f, 0f, 0f, 0f, -1f, -2f, -3f, -4f, -5f)),
)

fun DspState.applyPreset(p: EqPreset): DspState = copy(
    bands = p.bands.toList(),
    bassBoost = p.bassBoost,
    trebleBoost = p.trebleBoost,
    vocal = p.vocal,
)
