package com.rikodev.music.feature.metadata

/**
 * Filename-based metadata fallback ported from core/metadata/parseName.ts.
 * Used only when MediaStore / ID3 tags are missing a field. Real tags always win.
 */
data class ParsedName(
    val title: String,
    val artist: String?,
    val trackNumber: Int?,
)

private val AUDIO_EXT = Regex("\\.(mp3|m4a|aac|flac|wav|ogg|opus|wma|aiff|alac)$", RegexOption.IGNORE_CASE)

fun stripExtension(filename: String): String = AUDIO_EXT.replace(filename, "")

fun parseFromFilename(filename: String): ParsedName {
    var base = stripExtension(filename).trim()
    var trackNumber: Int? = null
    var artist: String? = null

    // Leading track number: "01 - Title" / "01. Title" / "01 Title"
    val numMatch = Regex("^(\\d{1,3})[\\s._-]+(.*)$").find(base)
    if (numMatch != null) {
        trackNumber = numMatch.groupValues[1].toIntOrNull()
        base = numMatch.groupValues[2].trim()
    }

    // "Artist - Title"
    val dashIndex = base.indexOf(" - ")
    if (dashIndex > 0) {
        artist = base.substring(0, dashIndex).trim()
        base = base.substring(dashIndex + 3).trim()
    }

    val title = base.ifBlank { stripExtension(filename) }
    return ParsedName(title = title, artist = artist?.ifBlank { null }, trackNumber = trackNumber)
}
