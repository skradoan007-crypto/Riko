package com.rikodev.music.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.rikodev.music.ui.theme.BarColors

/**
 * Real-FFT visualizer view ported from components/Visualizer.tsx — but the bars are
 * now driven by genuine FFT magnitudes captured from the audio session (see
 * VisualizerEngine), not the fake random animation the RN version used.
 */
@Composable
fun Visualizer(
    magnitudes: FloatArray,
    modifier: Modifier = Modifier,
    barCount: Int = 28,
    height: Dp = 120.dp,
) {
    Canvas(modifier = modifier.fillMaxWidth().height(height)) {
        val n = barCount.coerceAtMost(if (magnitudes.isEmpty()) barCount else magnitudes.size).coerceAtLeast(1)
        val gap = size.width * 0.012f
        val barWidth = (size.width - gap * (n - 1)) / n
        val brush = Brush.verticalGradient(BarColors.reversed())
        for (i in 0 until n) {
            val mag = magnitudes.getOrElse(i) { 0f }.coerceIn(0f, 1f)
            val barHeight = (size.height * (0.06f + 0.94f * mag))
            val x = i * (barWidth + gap)
            val y = size.height - barHeight
            drawRoundRect(
                brush = brush,
                topLeft = Offset(x, y),
                size = Size(barWidth, barHeight),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(barWidth / 2, barWidth / 2),
            )
        }
    }
}
