package com.rikodev.music.data.prefs

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Play history ported from historyStore: per-track playCounts + lastPlayedMs and a
 * recent list (max 200). Persisted as JSON in DataStore.
 */
data class HistoryState(
    val playCounts: Map<String, Int> = emptyMap(),
    val lastPlayedMs: Map<String, Long> = emptyMap(),
    val recent: List<String> = emptyList(),
)

@Singleton
class HistoryRepository @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val store = context.vibeDataStore
    private val key = stringPreferencesKey("history_json")
    private val maxRecent = 200

    val history: Flow<HistoryState> = store.data.map { prefs ->
        decode(prefs[key])
    }

    suspend fun recordPlay(id: String, now: Long) {
        store.edit { prefs ->
            val state = decode(prefs[key])
            val counts = state.playCounts.toMutableMap()
            counts[id] = (counts[id] ?: 0) + 1
            val last = state.lastPlayedMs.toMutableMap()
            last[id] = now
            val recent = ArrayList<String>(state.recent.size + 1)
            recent.add(id)
            for (r in state.recent) if (r != id) recent.add(r)
            prefs[key] = encode(
                HistoryState(counts, last, recent.take(maxRecent)),
            )
        }
    }

    suspend fun clear() {
        store.edit { it[key] = encode(HistoryState()) }
    }

    private fun encode(state: HistoryState): String {
        val root = JSONObject()
        root.put("playCounts", JSONObject(state.playCounts as Map<*, *>))
        root.put("lastPlayedMs", JSONObject(state.lastPlayedMs as Map<*, *>))
        root.put("recent", org.json.JSONArray(state.recent))
        return root.toString()
    }

    private fun decode(raw: String?): HistoryState {
        if (raw.isNullOrEmpty()) return HistoryState()
        return runCatching {
            val root = JSONObject(raw)
            val counts = mutableMapOf<String, Int>()
            root.optJSONObject("playCounts")?.let { obj ->
                obj.keys().forEach { k -> counts[k] = obj.getInt(k) }
            }
            val last = mutableMapOf<String, Long>()
            root.optJSONObject("lastPlayedMs")?.let { obj ->
                obj.keys().forEach { k -> last[k] = obj.getLong(k) }
            }
            val recent = mutableListOf<String>()
            root.optJSONArray("recent")?.let { arr ->
                for (i in 0 until arr.length()) recent.add(arr.getString(i))
            }
            HistoryState(counts, last, recent)
        }.getOrDefault(HistoryState())
    }
}
