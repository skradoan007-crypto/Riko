package com.rikodev.music.audio

import android.content.ComponentName
import android.content.Context
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.rikodev.music.data.model.RepeatMode
import com.rikodev.music.data.model.Track
import com.rikodev.music.data.prefs.HistoryRepository
import com.rikodev.music.data.prefs.ModifyRepository
import com.rikodev.music.feature.modify.DspState
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Player facade ported from stores/playerStore.ts. Owns the queue / repeat / shuffle
 * state and drives a Media3 MediaController bound to PlaybackService (real background
 * playback + notification). Speed/pitch are applied through PlaybackParameters and the
 * Modification Lab effects are pushed to the session-bound AudioFxController.
 */
data class PlayerUiState(
    val queue: List<Track> = emptyList(),
    val currentIndex: Int = -1,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val positionMs: Long = 0,
    val durationMs: Long = 0,
    val repeat: RepeatMode = RepeatMode.OFF,
    val shuffleOn: Boolean = false,
    val shuffleStrategyId: String = "true-random",
) {
    val current: Track? get() = queue.getOrNull(currentIndex)
}

@Singleton
class PlayerController @Inject constructor(
    @ApplicationContext private val context: Context,
    private val audioFx: AudioFxController,
    private val visualizer: VisualizerEngine,
    private val historyRepository: HistoryRepository,
    private val modifyRepository: ModifyRepository,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var controller: MediaController? = null

    private val _state = MutableStateFlow(PlayerUiState())
    val state: StateFlow<PlayerUiState> = _state.asStateFlow()

    /** Track list backing the current player timeline (parallel to media items). */
    private var queue: MutableList<Track> = mutableListOf()
    private var baseQueue: List<Track> = emptyList()
    private var dsp: DspState = DspState()
    private var dspEnabled = true

    fun bootstrap() {
        if (controller != null) return
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            controller = future.get()
            wireListeners()
            startPositionLoop()
        }, ContextCompat.getMainExecutor(context))

        // Live-apply Modification Lab changes (speed/pitch + native effects).
        scope.launch {
            modifyRepository.state.collect { (state, enabled) ->
                dsp = state
                dspEnabled = enabled
                applyDsp()
            }
        }
    }

    private fun wireListeners() {
        val c = controller ?: return
        c.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                visualizer.setActive(isPlaying)
                syncState()
            }

            override fun onPlaybackStateChanged(playbackState: Int) = syncState()

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                syncState()
                mediaItem?.mediaId?.let { id ->
                    scope.launch { historyRepository.recordPlay(id, System.currentTimeMillis()) }
                }
            }

            override fun onPositionDiscontinuity(
                oldPosition: Player.PositionInfo,
                newPosition: Player.PositionInfo,
                reason: Int,
            ) = syncState()
        })
        syncState()
    }

    private fun startPositionLoop() {
        scope.launch {
            while (true) {
                val c = controller
                if (c != null && c.isPlaying) syncState()
                delay(500)
            }
        }
    }

    private fun syncState() {
        val c = controller ?: return
        val idx = c.currentMediaItemIndex.takeIf { c.mediaItemCount > 0 } ?: -1
        _state.value = _state.value.copy(
            queue = queue.toList(),
            currentIndex = if (idx in queue.indices) idx else _state.value.currentIndex,
            isPlaying = c.isPlaying,
            isBuffering = c.playbackState == Player.STATE_BUFFERING,
            positionMs = c.currentPosition.coerceAtLeast(0),
            durationMs = c.duration.takeIf { it > 0 } ?: 0,
        )
    }

    private fun Track.toMediaItem(): MediaItem = MediaItem.Builder()
        .setUri(uri)
        .setMediaId(id)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .setArtworkUri(artworkUri?.let { android.net.Uri.parse(it) })
                .build(),
        )
        .build()

    fun setQueueAndPlay(tracks: List<Track>, startIndex: Int) {
        val c = controller ?: return
        if (tracks.isEmpty()) return
        baseQueue = tracks
        queue = tracks.toMutableList()
        c.setMediaItems(queue.map { it.toMediaItem() }, startIndex, 0)
        c.prepare()
        applyDsp()
        c.play()
        _state.value = _state.value.copy(shuffleOn = false)
        syncState()
    }

    fun playTrackAt(index: Int) {
        val c = controller ?: return
        if (index in queue.indices) {
            c.seekTo(index, 0)
            c.play()
            syncState()
        }
    }

    fun toggle() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun next(manual: Boolean = true) {
        controller?.seekToNextMediaItem()
    }

    fun previous() {
        val c = controller ?: return
        if (c.currentPosition > 4000) c.seekTo(0) else c.seekToPreviousMediaItem()
    }

    fun seekTo(positionMs: Long) {
        controller?.seekTo(positionMs)
        syncState()
    }

    fun cycleRepeat() {
        val c = controller ?: return
        val next = when (_state.value.repeat) {
            RepeatMode.OFF -> RepeatMode.ALL
            RepeatMode.ALL -> RepeatMode.ONE
            RepeatMode.ONE -> RepeatMode.OFF
        }
        c.repeatMode = when (next) {
            RepeatMode.OFF -> Player.REPEAT_MODE_OFF
            RepeatMode.ALL -> Player.REPEAT_MODE_ALL
            RepeatMode.ONE -> Player.REPEAT_MODE_ONE
        }
        _state.value = _state.value.copy(repeat = next)
    }

    fun setShuffleStrategy(id: String) {
        _state.value = _state.value.copy(shuffleStrategyId = id)
    }

    /** Toggle the custom strategy shuffle: on -> apply current order, off -> restore base. */
    fun toggleShuffle(reorder: (List<Track>) -> List<Track>) {
        val turnOn = !_state.value.shuffleOn
        if (turnOn) {
            applyShuffleOrder(reorder(if (baseQueue.isNotEmpty()) baseQueue else queue))
            _state.value = _state.value.copy(shuffleOn = true)
        } else {
            if (baseQueue.isNotEmpty()) applyOrder(baseQueue)
            _state.value = _state.value.copy(shuffleOn = false)
        }
    }

    /** Replace the queue with a strategy-produced order and start from the top. */
    fun applyShuffleOrder(order: List<Track>) {
        if (order.isEmpty()) return
        if (baseQueue.isEmpty()) baseQueue = order
        applyOrder(order)
        _state.value = _state.value.copy(shuffleOn = true)
    }

    private fun applyOrder(order: List<Track>) {
        val c = controller ?: return
        queue = order.toMutableList()
        c.setMediaItems(queue.map { it.toMediaItem() }, 0, 0)
        c.prepare()
        applyDsp()
        c.play()
        syncState()
    }

    fun addToQueue(track: Track) {
        val c = controller ?: return
        queue.add(track)
        c.addMediaItem(track.toMediaItem())
        syncState()
    }

    fun playNextUp(track: Track) {
        val c = controller ?: return
        val insertAt = (c.currentMediaItemIndex + 1).coerceIn(0, queue.size)
        queue.add(insertAt, track)
        c.addMediaItem(insertAt, track.toMediaItem())
        syncState()
    }

    private fun applyDsp() {
        val c = controller
        // Speed + pitch are real native PlaybackParameters on the shared player.
        c?.playbackParameters = PlaybackParameters(
            if (dspEnabled) dsp.speed else 1f,
            if (dspEnabled) dsp.pitch else 1f,
        )
        // EQ / bass / treble / vocal / reverb / stereo width / preamp.
        audioFx.apply(dsp, dspEnabled)
    }
}
