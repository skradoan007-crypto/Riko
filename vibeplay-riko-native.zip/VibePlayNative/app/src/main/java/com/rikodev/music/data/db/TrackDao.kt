package com.rikodev.music.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

/** DTO for duplicate-group aggregation (replaces findDuplicateGroups SQL). */
data class DuplicateRow(val contentHash: String, val ids: String, val count: Int)

@Dao
interface TrackDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(tracks: List<TrackEntity>)

    /** Bulk replace in a single transaction — mirrors the original upsertTracks txn. */
    @Transaction
    suspend fun replaceLibrary(tracks: List<TrackEntity>) {
        upsertAll(tracks)
    }

    @Query("SELECT * FROM tracks ORDER BY title COLLATE NOCASE ASC")
    fun observeAll(): Flow<List<TrackEntity>>

    @Query("SELECT * FROM tracks ORDER BY title COLLATE NOCASE ASC")
    suspend fun getAll(): List<TrackEntity>

    @Query("SELECT * FROM tracks WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): TrackEntity?

    @Query("SELECT COUNT(*) FROM tracks")
    suspend fun count(): Int

    @Query("DELETE FROM tracks")
    suspend fun clear()

    @Query("DELETE FROM tracks WHERE id IN (:ids)")
    suspend fun deleteByIds(ids: List<String>)

    @Query("UPDATE tracks SET playCount = playCount + 1, lastPlayedMs = :ts WHERE id = :id")
    suspend fun markPlayed(id: String, ts: Long)

    /** Groups of tracks sharing a contentHash (duplicates). */
    @Query(
        "SELECT contentHash AS contentHash, group_concat(id) AS ids, COUNT(*) AS count " +
            "FROM tracks GROUP BY contentHash HAVING COUNT(*) > 1",
    )
    suspend fun duplicateGroups(): List<DuplicateRow>
}
