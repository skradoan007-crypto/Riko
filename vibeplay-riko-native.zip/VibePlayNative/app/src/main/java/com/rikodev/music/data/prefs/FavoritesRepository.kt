package com.rikodev.music.data.prefs

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

/** Favorites — ported from favoritesStore (persisted set of track ids). */
@Singleton
class FavoritesRepository @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val store = context.vibeDataStore
    private val key = stringSetPreferencesKey("favorite_ids")

    val favoriteIds: Flow<Set<String>> = store.data.map { it[key] ?: emptySet() }

    suspend fun toggle(id: String) {
        store.edit { prefs ->
            val current = prefs[key]?.toMutableSet() ?: mutableSetOf()
            if (!current.add(id)) current.remove(id)
            prefs[key] = current
        }
    }

    suspend fun set(id: String, favorite: Boolean) {
        store.edit { prefs ->
            val current = prefs[key]?.toMutableSet() ?: mutableSetOf()
            if (favorite) current.add(id) else current.remove(id)
            prefs[key] = current
        }
    }
}
