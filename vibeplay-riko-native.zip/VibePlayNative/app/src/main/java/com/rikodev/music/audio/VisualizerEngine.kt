package com.rikodev.music.audio

import android.media.audiofx.Visualizer
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.hypot
import kotlin.math.ln

/**
 * Real audio visualizer engine — the headline replacement for the fake JS bar
 * animation. Taps the actual output via android.media.audiofx.Visualizer on the
 * ExoPlayer session and emits normalized FFT magnitudes for [bands] bars.
 */
class VisualizerEngine(private val bands: Int = 28) {
    private var visualizer: Visualizer? = null
    private var sessionId = 0

    private val _magnitudes = MutableStateFlow(FloatArray(bands))
    val magnitudes: StateFlow<FloatArray> = _magnitudes

    @Synchronized
    fun attach(audioSessionId: Int) {
        if (audioSessionId == 0 || audioSessionId == sessionId) return
        release()
        sessionId = audioSessionId
        runCatching {
            visualizer = Visualizer(audioSessionId).apply {
                captureSize = Visualizer.getCaptureSizeRange()[1]
                setDataCaptureListener(
                    object : Visualizer.OnDataCaptureListener {
                        override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, rate: Int) {}
                        override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, rate: Int) {
                            if (fft != null) _magnitudes.value = computeBars(fft)
                        }
                    },
                    Visualizer.getMaxCaptureRate() / 2,
                    false,
                    true,
                )
                enabled = true
            }
        }.onFailure { Log.w(TAG, "Visualizer init failed", it) }
    }

    private fun computeBars(fft: ByteArray): FloatArray {
        val n = fft.size / 2
        val out = FloatArray(bands)
        val perBand = maxOf(1, n / bands)
        for (b in 0 until bands) {
            var sum = 0.0
            val start = b * perBand
            val end = minOf(n, start + perBand)
            var count = 0
            var i = start
            while (i < end) {
                val re = fft[2 * i].toInt().toDouble()
                val im = fft[2 * i + 1].toInt().toDouble()
                sum += hypot(re, im)
                count++
                i++
            }
            val avg = if (count > 0) sum / count else 0.0
            // log scale -> 0..1
            val norm = (ln(1.0 + avg) / ln(1.0 + 128.0)).coerceIn(0.0, 1.0)
            out[b] = norm.toFloat()
        }
        return out
    }

    @Synchronized
    fun setActive(active: Boolean) {
        runCatching { visualizer?.enabled = active }
    }

    @Synchronized
    fun release() {
        runCatching { visualizer?.enabled = false }
        runCatching { visualizer?.release() }
        visualizer = null
        sessionId = 0
        _magnitudes.value = FloatArray(bands)
    }

    companion object {
        private const val TAG = "VisualizerEngine"
    }
}
