package com.rikodev.music.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.rikodev.music.data.model.Track
import com.rikodev.music.ui.theme.VibeTheme
import com.rikodev.music.ui.theme.vibeSpring
import com.rikodev.music.ui.util.msToClock

/**
 * Library / queue list row ported from components/TrackRow.tsx: album-art thumb (or
 * neon placeholder), title/artist, an animated heart favorite toggle and an active
 * highlight when the row is the currently playing track.
 */
@Composable
fun TrackRow(
    track: Track,
    isActive: Boolean,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = VibeTheme.colors
    val heartScale by animateFloatAsState(if (track.isFavorite) 1.15f else 1f, vibeSpring(), label = "heart")
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(if (isActive) colors.primaryContainer.copy(alpha = 0.6f) else androidx.compose.ui.graphics.Color.Transparent)
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            modifier = Modifier
                .size(50.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Brush.linearGradient(listOf(colors.accentCyan.copy(alpha = 0.4f), colors.accentViolet.copy(alpha = 0.4f)))),
            contentAlignment = Alignment.Center,
        ) {
            if (track.artworkUri != null) {
                AsyncImage(
                    model = track.artworkUri,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(50.dp).clip(RoundedCornerShape(12.dp)),
                )
            } else {
                Icon(Icons.Filled.MusicNote, contentDescription = null, tint = colors.onPrimary)
            }
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                track.title,
                color = if (isActive) colors.primary else colors.onSurface,
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                "${track.artist}  •  ${msToClock(track.durationMs)}",
                color = colors.onSurfaceVariant,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Icon(
            imageVector = if (track.isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
            contentDescription = "Favorite",
            tint = if (track.isFavorite) colors.accentPink else colors.onSurfaceVariant,
            modifier = Modifier
                .scale(heartScale)
                .size(24.dp)
                .clickable { onToggleFavorite() },
        )
    }
}
