package com.rikodev.music.ui.screens.player

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rikodev.music.audio.PlayerController
import com.rikodev.music.audio.PlayerUiState
import com.rikodev.music.audio.VisualizerEngine
import com.rikodev.music.data.repo.LibraryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Shared player view model used by both the docked MiniPlayer and the full Now Playing
 * screen. Exposes the live PlayerUiState + real visualizer magnitudes and proxies
 * transport controls to the singleton PlayerController.
 */
@HiltViewModel
class PlayerViewModel @Inject constructor(
    private val playerController: PlayerController,
    private val visualizerEngine: VisualizerEngine,
    private val libraryRepository: LibraryRepository,
) : ViewModel() {

    val state: StateFlow<PlayerUiState> = playerController.state
    val magnitudes: StateFlow<FloatArray> = visualizerEngine.magnitudes

    fun toggle() = playerController.toggle()
    fun next() = playerController.next()
    fun previous() = playerController.previous()
    fun seekTo(positionMs: Long) = playerController.seekTo(positionMs)
    fun cycleRepeat() = playerController.cycleRepeat()
    fun toggleShuffle() = playerController.toggleShuffle { it.shuffled() }

    fun toggleFavoriteCurrent() {
        val current = state.value.current ?: return
        viewModelScope.launch { libraryRepository.toggleFavorite(current.id) }
    }
}
