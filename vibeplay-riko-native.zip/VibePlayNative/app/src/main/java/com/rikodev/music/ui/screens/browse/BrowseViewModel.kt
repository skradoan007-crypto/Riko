package com.rikodev.music.ui.screens.browse

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rikodev.music.audio.PlayerController
import com.rikodev.music.data.model.Track
import com.rikodev.music.data.repo.BrowseRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class BrowseUiState(
    val tracks: List<Track> = emptyList(),
    val sourceLabel: String = "",
    val loading: Boolean = false,
)

/**
 * MODE 1 view model — ephemeral SAF folder/file browsing. Kept completely separate
 * from the persistent Library (Mode 2), matching the two-workflow design.
 */
@HiltViewModel
class BrowseViewModel @Inject constructor(
    private val browseRepository: BrowseRepository,
    private val playerController: PlayerController,
) : ViewModel() {

    private val _state = MutableStateFlow(BrowseUiState())
    val state: StateFlow<BrowseUiState> = _state.asStateFlow()

    fun openFolder(treeUri: Uri) {
        _state.value = _state.value.copy(loading = true)
        viewModelScope.launch {
            val tracks = browseRepository.tracksFromFolder(treeUri)
            _state.value = BrowseUiState(tracks = tracks, sourceLabel = "Folder • ${tracks.size} tracks", loading = false)
        }
    }

    fun pickFiles(uris: List<Uri>) {
        _state.value = _state.value.copy(loading = true)
        viewModelScope.launch {
            val tracks = browseRepository.tracksFromFiles(uris)
            _state.value = BrowseUiState(tracks = tracks, sourceLabel = "Picked • ${tracks.size} tracks", loading = false)
        }
    }

    fun play(track: Track) {
        val list = _state.value.tracks
        val index = list.indexOfFirst { it.id == track.id }.coerceAtLeast(0)
        playerController.setQueueAndPlay(list, index)
    }

    fun playAll() {
        if (_state.value.tracks.isNotEmpty()) playerController.setQueueAndPlay(_state.value.tracks, 0)
    }
}
