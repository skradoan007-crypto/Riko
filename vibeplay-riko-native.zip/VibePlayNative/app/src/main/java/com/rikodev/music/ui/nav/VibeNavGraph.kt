package com.rikodev.music.ui.nav

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.rikodev.music.ui.components.GlassTabBar
import com.rikodev.music.ui.components.MiniPlayer
import com.rikodev.music.ui.screens.SplashScreen
import com.rikodev.music.ui.screens.browse.BrowseScreen
import com.rikodev.music.ui.screens.library.LibraryScreen
import com.rikodev.music.ui.screens.modify.ModifyScreen
import com.rikodev.music.ui.screens.player.NowPlayingScreen
import com.rikodev.music.ui.screens.player.PlayerViewModel
import com.rikodev.music.ui.screens.settings.SettingsScreen
import com.rikodev.music.ui.screens.shuffle.ShuffleScreen

object Routes {
    const val SPLASH = "splash"
    const val MAIN = "main"
    const val NOW_PLAYING = "now_playing"
    const val MODIFY = "modify"
}

/**
 * Root navigation ported from the Expo Stack: splash gate → tabbed main shell, with
 * Now Playing and Modification Lab presented as slide-up sheets.
 */
@Composable
fun VibeNavGraph() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = Routes.SPLASH) {
        composable(Routes.SPLASH) {
            SplashScreen(onDone = {
                navController.navigate(Routes.MAIN) {
                    popUpTo(Routes.SPLASH) { inclusive = true }
                }
            })
        }
        composable(Routes.MAIN) {
            MainScaffold(
                onOpenNowPlaying = { navController.navigate(Routes.NOW_PLAYING) },
                onOpenModify = { navController.navigate(Routes.MODIFY) },
            )
        }
        composable(
            Routes.NOW_PLAYING,
            enterTransition = { slideInVertically(tween(320)) { it } + fadeIn() },
            exitTransition = { slideOutVertically(tween(320)) { it } + fadeOut() },
            popExitTransition = { slideOutVertically(tween(320)) { it } + fadeOut() },
        ) {
            NowPlayingScreen(
                onDismiss = { navController.popBackStack() },
                onOpenModify = { navController.navigate(Routes.MODIFY) },
            )
        }
        composable(
            Routes.MODIFY,
            enterTransition = { slideInVertically(tween(320)) { it } + fadeIn() },
            popExitTransition = { slideOutVertically(tween(320)) { it } + fadeOut() },
        ) {
            ModifyScreen(onDismiss = { navController.popBackStack() })
        }
    }
}

@Composable
private fun MainScaffold(
    onOpenNowPlaying: () -> Unit,
    onOpenModify: () -> Unit,
) {
    var currentTab by remember { mutableStateOf("library") }
    val playerViewModel: PlayerViewModel = hiltViewModel()
    val playerState by playerViewModel.state.collectAsStateWithLifecycle()

    Box(modifier = Modifier.fillMaxSize()) {
        when (currentTab) {
            "library" -> LibraryScreen(onOpenNowPlaying = onOpenNowPlaying)
            "browse" -> BrowseScreen(onOpenNowPlaying = onOpenNowPlaying)
            "shuffle" -> ShuffleScreen(onOpenNowPlaying = onOpenNowPlaying)
            "settings" -> SettingsScreen()
        }

        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 8.dp),
        ) {
            MiniPlayer(
                state = playerState,
                onOpen = onOpenNowPlaying,
                onToggle = playerViewModel::toggle,
                onNext = playerViewModel::next,
                modifier = Modifier.padding(bottom = 10.dp),
            )
            GlassTabBar(currentRoute = currentTab, onSelect = { currentTab = it })
        }
    }
}
