package com.rikodev.music.ui.screens.modify

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.rikodev.music.ui.components.AmbientBackground
import com.rikodev.music.ui.components.GlassButton
import com.rikodev.music.ui.components.GlassButtonVariant
import com.rikodev.music.ui.components.GlassSurface
import com.rikodev.music.ui.theme.VibeTheme

/**
 * Modification Lab — the full native DSP surface ported from app/modify.tsx. Master
 * enable (default on), live Speed / Pitch / Pre-amp, 8 preset chips, the 10-band EQ
 * (−12..+12 dB) and the enhancer bank (bass / treble / vocal / reverb / echo / stereo
 * width). Every control is bound to the real android.media.audiofx session.
 */
@Composable
fun ModifyScreen(
    onDismiss: () -> Unit,
    viewModel: ModifyViewModel = hiltViewModel(),
) {
    val colors = VibeTheme.colors
    val dsp by viewModel.dsp.collectAsStateWithLifecycle()
    val enabled by viewModel.enabled.collectAsStateWithLifecycle()

    AmbientBackground {
        LazyColumn(
            modifier = Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 18.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 8.dp, bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Filled.KeyboardArrowDown,
                        contentDescription = "Close",
                        tint = colors.onSurface,
                        modifier = Modifier.clickable { onDismiss() },
                    )
                    Text("Modification Lab", modifier = Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = colors.onSurface)
                    Switch(checked = enabled, onCheckedChange = viewModel::setEnabled)
                }
            }

            item {
                GlassSurface(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "Native audio effects are applied directly to the playback session (real EQ, reverb, virtualizer, loudness, pitch + speed).",
                        color = colors.onSurfaceVariant,
                        fontSize = 12.sp,
                    )
                }
            }

            item {
                GlassSurface(modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Tempo & Tone", fontWeight = FontWeight.SemiBold, color = colors.onSurface, fontSize = 15.sp)
                        LabeledSlider("Speed", dsp.speed, 0.5f..2f, viewModel::setSpeed, "%.2fx".format(dsp.speed))
                        LabeledSlider("Pitch", dsp.pitch, 0.5f..2f, viewModel::setPitch, "%.2fx".format(dsp.pitch))
                        LabeledSlider("Pre-amp", dsp.preamp, 0f..1f, viewModel::setPreamp, "${(dsp.preamp * 100).toInt()}%")
                    }
                }
            }

            item {
                GlassSurface(modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Presets", fontWeight = FontWeight.SemiBold, color = colors.onSurface, fontSize = 15.sp)
                        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            viewModel.presets.forEach { preset ->
                                Text(
                                    preset.name,
                                    color = colors.onSurface,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(999.dp))
                                        .background(colors.surfaceVariant)
                                        .clickable { viewModel.applyPreset(preset) }
                                        .padding(horizontal = 14.dp, vertical = 8.dp),
                                )
                            }
                        }
                    }
                }
            }

            item {
                GlassSurface(modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("10-Band Equalizer", fontWeight = FontWeight.SemiBold, color = colors.onSurface, fontSize = 15.sp)
                        viewModel.frequencies.forEachIndexed { index, freq ->
                            val value = dsp.bands.getOrElse(index) { 0f }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    if (freq >= 1000) "${freq / 1000}k" else "$freq",
                                    modifier = Modifier.width(44.dp),
                                    color = colors.onSurfaceVariant,
                                    fontSize = 12.sp,
                                )
                                Slider(
                                    value = value,
                                    onValueChange = { viewModel.setBand(index, it) },
                                    valueRange = -12f..12f,
                                    modifier = Modifier.weight(1f),
                                    colors = SliderDefaults.colors(thumbColor = colors.accent, activeTrackColor = colors.accent),
                                )
                                Text("%+.0f".format(value), modifier = Modifier.width(40.dp), color = colors.onSurface, fontSize = 12.sp, textAlign = TextAlign.End)
                            }
                        }
                    }
                }
            }

            item {
                GlassSurface(modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Enhancers", fontWeight = FontWeight.SemiBold, color = colors.onSurface, fontSize = 15.sp)
                        LabeledSlider("Bass", dsp.bassBoost, 0f..1f, viewModel::setBassBoost)
                        LabeledSlider("Treble", dsp.trebleBoost, 0f..1f, viewModel::setTrebleBoost)
                        LabeledSlider("Vocal", dsp.vocal, 0f..1f, viewModel::setVocal)
                        LabeledSlider("Reverb", dsp.reverb, 0f..1f, viewModel::setReverb)
                        LabeledSlider("Echo", dsp.echo, 0f..1f, viewModel::setEcho)
                        LabeledSlider("Stereo width", dsp.stereoWidth, 0f..1f, viewModel::setStereoWidth)
                    }
                }
            }

            item {
                GlassButton(
                    text = "Reset all",
                    onClick = viewModel::reset,
                    variant = GlassButtonVariant.GLASS,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}

@Composable
private fun LabeledSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
    valueLabel: String? = null,
) {
    val colors = VibeTheme.colors
    Column {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = colors.onSurface, fontSize = 13.sp)
            Text(valueLabel ?: "${(value * 100).toInt()}%", color = colors.onSurfaceVariant, fontSize = 12.sp)
        }
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range,
            colors = SliderDefaults.colors(thumbColor = colors.accent, activeTrackColor = colors.accent),
        )
    }
}
