package com.rikodev.music.data.model

/**
 * Domain models ported 1:1 from types/models.ts. The Track shape is the canonical
 * record used across scanning, the database, the player and every screen.
 */
data class Track(
    val id: String,
    val uri: String,
    val filename: String,
    val title: String,
    val artist: String,
    val album: String,
    val albumArtist: String? = null,
    val genre: String? = null,
    val mood: String? = null,
    val durationMs: Long,
    val trackNumber: Int? = null,
    val year: Int? = null,
    val folderPath: String,
    val folderName: String,
    val sizeBytes: Long,
    val dateAddedMs: Long,
    val artworkUri: String? = null,
    val playCount: Int = 0,
    val lastPlayedMs: Long? = null,
    val isFavorite: Boolean = false,
)

data class Album(
    val id: String,
    val name: String,
    val artist: String,
    val trackCount: Int,
    val artworkUri: String? = null,
)

data class Artist(
    val id: String,
    val name: String,
    val trackCount: Int,
)

data class Genre(
    val id: String,
    val name: String,
    val trackCount: Int,
)

data class FolderNode(
    val path: String,
    val name: String,
    val trackCount: Int,
)

data class Playlist(
    val id: String,
    val name: String,
    val trackIds: List<String>,
    val createdMs: Long,
    val updatedMs: Long,
)

data class LyricLine(
    val timeMs: Long,
    val text: String,
)

enum class RepeatMode { OFF, ALL, ONE }

enum class SortKey { TITLE, ARTIST, ALBUM, DATE_ADDED, DURATION, PLAY_COUNT }

enum class SortDir { ASC, DESC }

/** Scan progress phases ported from the scanner state machine. */
enum class ScanPhase { IDLE, REQUESTING, SCANNING, INDEXING, DONE, ERROR }

data class ScanProgress(
    val phase: ScanPhase = ScanPhase.IDLE,
    val scanned: Int = 0,
    val total: Int = 0,
    val message: String? = null,
)

/** A set of tracks that share the same content hash (duplicate detection). */
data class DuplicateGroup(
    val contentHash: String,
    val trackIds: List<String>,
)
