package com.rikodev.music.audio

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.PresetReverb
import android.media.audiofx.Virtualizer
import android.util.Log
import com.rikodev.music.feature.modify.DspState
import com.rikodev.music.feature.modify.EQ_FREQUENCIES
import kotlin.math.roundToInt

/**
 * Real native audio-effects engine bound to the ExoPlayer audio session id.
 *
 * This is the headline upgrade over the Expo build, where expo-av exposed no EQ at
 * all and a fragile global-session-0 hack was used. Here every Modification Lab
 * control maps to a genuine android.media.audiofx effect on the actual player session:
 *   • 10-band EQ      -> Equalizer (band gains interpolated onto device bands)
 *   • bass boost      -> BassBoost + low-band EQ lift
 *   • treble boost    -> high-band EQ lift
 *   • vocal enhancer  -> mid-band EQ lift
 *   • reverb          -> PresetReverb
 *   • echo            -> PresetReverb (large-hall tail) blended in
 *   • stereo width    -> Virtualizer
 *   • preamp          -> LoudnessEnhancer (target gain mB)
 * Speed + pitch are applied separately on the ExoPlayer PlaybackParameters.
 */
class AudioFxController {
    private var sessionId: Int = 0
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var reverb: PresetReverb? = null
    private var loudness: LoudnessEnhancer? = null

    private var lastState: DspState = DspState()
    private var enabled: Boolean = true

    @Synchronized
    fun attach(audioSessionId: Int) {
        if (audioSessionId == 0 || audioSessionId == sessionId) return
        release()
        sessionId = audioSessionId
        runCatching { equalizer = Equalizer(0, audioSessionId).apply { this.enabled = true } }
            .onFailure { Log.w(TAG, "Equalizer init failed", it) }
        runCatching { bassBoost = BassBoost(0, audioSessionId).apply { this.enabled = true } }
        runCatching { virtualizer = Virtualizer(0, audioSessionId).apply { this.enabled = true } }
        runCatching { reverb = PresetReverb(0, audioSessionId).apply { this.enabled = true } }
        runCatching { loudness = LoudnessEnhancer(audioSessionId).apply { this.enabled = true } }
        apply(lastState, enabled)
    }

    @Synchronized
    fun apply(state: DspState, isEnabled: Boolean) {
        lastState = state
        enabled = isEnabled
        val eq = equalizer
        if (eq != null) {
            runCatching {
                eq.enabled = isEnabled
                if (isEnabled) {
                    val bandCount = eq.numberOfBands.toInt()
                    val range = eq.bandLevelRange // [min, max] in millibels
                    val minLevel = range[0].toInt()
                    val maxLevel = range[1].toInt()
                    for (b in 0 until bandCount) {
                        val centerHz = eq.getCenterFreq(b.toShort()) / 1000 // mHz -> Hz
                        val gainDb = interpolatedGain(state, centerHz)
                        val mb = (gainDb * 100).roundToInt().coerceIn(minLevel, maxLevel)
                        eq.setBandLevel(b.toShort(), mb.toShort())
                    }
                }
            }
        }
        runCatching {
            bassBoost?.let {
                if (it.strengthSupported) {
                    it.enabled = isEnabled && state.bassBoost > 0f
                    it.setStrength((state.bassBoost * 1000).roundToInt().coerceIn(0, 1000).toShort())
                }
            }
        }
        runCatching {
            virtualizer?.let {
                if (it.strengthSupported) {
                    it.enabled = isEnabled && state.stereoWidth > 0f
                    it.setStrength((state.stereoWidth * 1000).roundToInt().coerceIn(0, 1000).toShort())
                }
            }
        }
        runCatching {
            reverb?.let {
                val amount = maxOf(state.reverb, state.echo)
                it.enabled = isEnabled && amount > 0f
                it.preset = reverbPreset(state).toShort()
            }
        }
        runCatching {
            loudness?.let {
                it.enabled = isEnabled
                // preamp 0..1 -> 0..1200 mB target gain.
                it.setTargetGain((state.preamp * 1200).roundToInt().coerceIn(0, 1200))
            }
        }
    }

    /** Interpolate the 10-band slider gains onto an arbitrary device band center. */
    private fun interpolatedGain(state: DspState, hz: Int): Float {
        val freqs = EQ_FREQUENCIES
        var base = when {
            hz <= freqs.first() -> state.bands.first()
            hz >= freqs.last() -> state.bands.last()
            else -> {
                var result = state.bands.first()
                for (i in 0 until freqs.size - 1) {
                    if (hz in freqs[i]..freqs[i + 1]) {
                        val t = (hz - freqs[i]).toFloat() / (freqs[i + 1] - freqs[i])
                        result = state.bands[i] + (state.bands[i + 1] - state.bands[i]) * t
                        break
                    }
                }
                result
            }
        }
        // Enhancer lifts layered on top of the EQ curve.
        if (hz <= 250) base += state.bassBoost * 6f
        if (hz in 800..4000) base += state.vocal * 5f
        if (hz >= 6000) base += state.trebleBoost * 6f
        return base.coerceIn(-15f, 15f)
    }

    private fun reverbPreset(state: DspState): Int {
        val amount = maxOf(state.reverb, state.echo)
        return when {
            amount <= 0f -> PresetReverb.PRESET_NONE.toInt()
            amount < 0.2f -> PresetReverb.PRESET_SMALLROOM.toInt()
            amount < 0.4f -> PresetReverb.PRESET_MEDIUMROOM.toInt()
            amount < 0.6f -> PresetReverb.PRESET_LARGEROOM.toInt()
            amount < 0.8f -> PresetReverb.PRESET_MEDIUMHALL.toInt()
            else -> PresetReverb.PRESET_LARGEHALL.toInt()
        }
    }

    @Synchronized
    fun release() {
        runCatching { equalizer?.release() }
        runCatching { bassBoost?.release() }
        runCatching { virtualizer?.release() }
        runCatching { reverb?.release() }
        runCatching { loudness?.release() }
        equalizer = null
        bassBoost = null
        virtualizer = null
        reverb = null
        loudness = null
        sessionId = 0
    }

    companion object {
        private const val TAG = "AudioFxController"
    }
}
