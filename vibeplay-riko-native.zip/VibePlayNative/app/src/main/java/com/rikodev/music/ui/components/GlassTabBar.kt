package com.rikodev.music.ui.components

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import com.rikodev.music.ui.theme.VibeTheme

data class TabItem(val route: String, val icon: ImageVector)

val VIBE_TABS = listOf(
    TabItem("library", Icons.Filled.LibraryMusic),
    TabItem("browse", Icons.Filled.FolderOpen),
    TabItem("shuffle", Icons.Filled.Shuffle),
    TabItem("settings", Icons.Filled.Settings),
)

/**
 * Floating glass dock ported from components/GlassTabBar.tsx — a pill-shaped bar with
 * an animated active pill behind the selected icon.
 */
@Composable
fun GlassTabBar(
    currentRoute: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = VibeTheme.colors
    val haptics = LocalHapticFeedback.current
    val shape = RoundedCornerShape(30.dp)
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 28.dp)
            .height(60.dp)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(colors.glassFillLight, colors.glassFillMid)))
            .border(BorderStroke(1.dp, colors.glassBorder), shape)
            .padding(horizontal = 10.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        VIBE_TABS.forEach { tab ->
            val selected = currentRoute == tab.route
            val pad by animateDpAsState(if (selected) 18.dp else 12.dp, label = "pad")
            val interaction = remember { MutableInteractionSource() }
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(
                        if (selected)
                            Brush.horizontalGradient(listOf(colors.primary, colors.accent))
                        else
                            Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent)),
                    )
                    .clickable(interactionSource = interaction, indication = null) {
                        haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onSelect(tab.route)
                    }
                    .padding(horizontal = pad, vertical = 12.dp),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    tab.icon,
                    contentDescription = tab.route,
                    tint = if (selected) Color.White else colors.onSurfaceVariant,
                    modifier = Modifier.size(24.dp),
                )
            }
        }
    }
}
