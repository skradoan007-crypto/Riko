package com.rikodev.music.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.rikodev.music.ui.theme.VibeTheme
import kotlin.math.cos
import kotlin.math.sin

/**
 * Ambient gradient background with three slowly drifting neon glow orbs — ported
 * from components/AmbientBackground.tsx. In AMOLED mode the orbs are suppressed for a
 * pure-black canvas, exactly like the RN original.
 */
@Composable
fun AmbientBackground(
    modifier: Modifier = Modifier,
    animated: Boolean = true,
    content: @Composable () -> Unit,
) {
    val colors = VibeTheme.colors
    val transition = rememberInfiniteTransition(label = "ambient")
    val t by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (animated) 16000 else 1, easing = { it }),
            repeatMode = RepeatMode.Restart,
        ),
        label = "drift",
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(colors.background, colors.surfaceAlt, colors.background),
                ),
            ),
    ) {
        if (!colors.isAmoled) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val orbs = listOf(
                    Triple(colors.accentCyan, Offset(0.22f, 0.18f), 0.0),
                    Triple(colors.accentViolet, Offset(0.82f, 0.30f), 2.1),
                    Triple(colors.accentPink, Offset(0.5f, 0.85f), 4.2),
                )
                orbs.forEach { (color, base, phase) ->
                    val dx = (cos(t + phase.toFloat()) * 0.06f)
                    val dy = (sin(t + phase.toFloat()) * 0.06f)
                    val center = Offset((base.x + dx) * w, (base.y + dy) * h)
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(color.copy(alpha = 0.34f), Color.Transparent),
                            center = center,
                            radius = w * 0.55f,
                        ),
                        radius = w * 0.55f,
                        center = center,
                    )
                }
            }
        }
        content()
    }
}
