package com.rikodev.music.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import com.rikodev.music.ui.theme.VibeTheme
import com.rikodev.music.ui.util.msToClock

/**
 * Scrubbable seek bar ported from components/SeekBar.tsx. While dragging it shows a
 * local value and only commits the seek on release, matching the RN behavior.
 */
@Composable
fun SeekBar(
    positionMs: Long,
    durationMs: Long,
    onSeek: (Long) -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = VibeTheme.colors
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableStateOf(0f) }
    val max = durationMs.coerceAtLeast(1L).toFloat()
    val value = if (dragging) dragValue else positionMs.coerceIn(0, durationMs).toFloat()

    Column(modifier = modifier.fillMaxWidth()) {
        Slider(
            value = value.coerceIn(0f, max),
            onValueChange = { dragging = true; dragValue = it },
            onValueChangeFinished = { dragging = false; onSeek(dragValue.toLong()) },
            valueRange = 0f..max,
            colors = SliderDefaults.colors(
                thumbColor = colors.accent,
                activeTrackColor = colors.accent,
                inactiveTrackColor = colors.outlineVariant,
            ),
        )
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(msToClock(value.toLong()), color = colors.onSurfaceVariant, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Text(msToClock(durationMs), color = colors.onSurfaceVariant, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }
    }
}
