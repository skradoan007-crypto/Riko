package com.rikodev.music.ui.screens.shuffle

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.rikodev.music.feature.shuffle.GroupByKey
import com.rikodev.music.ui.components.AmbientBackground
import com.rikodev.music.ui.components.GlassButton
import com.rikodev.music.ui.components.GlassSurface
import com.rikodev.music.ui.theme.VibeTheme

private val GROUP_KEYS = listOf(
    GroupByKey.ARTIST,
    GroupByKey.ALBUM,
    GroupByKey.GENRE,
    GroupByKey.FOLDER,
    GroupByKey.DECADE,
    GroupByKey.MOOD,
)

/**
 * Advanced Shuffle Lab — flagship Group Shuffle card (grouping key chips + start) plus
 * the full list of 12 shuffle strategies. Ported from app/(tabs)/shuffle.tsx.
 */
@Composable
fun ShuffleScreen(
    onOpenNowPlaying: () -> Unit,
    viewModel: ShuffleViewModel = hiltViewModel(),
) {
    val colors = VibeTheme.colors
    val config by viewModel.config.collectAsStateWithLifecycle()
    val plan by viewModel.lastPlan.collectAsStateWithLifecycle()

    AmbientBackground {
        LazyColumn(
            modifier = Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 18.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 12.dp, bottom = 170.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Text("Shuffle Lab", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = colors.onSurface)
            }
            item {
                GlassSurface(modifier = Modifier.fillMaxWidth(), accentBorder = true) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = colors.accent)
                            Text("Group Shuffle", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = colors.onSurface)
                        }
                        Text(
                            "Build a smart rotation across groups — the flagship engine with weighting, diversity and no-repeat controls.",
                            color = colors.onSurfaceVariant,
                            fontSize = 13.sp,
                        )
                        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            GROUP_KEYS.forEach { key ->
                                val selected = config.groupBy == key
                                Text(
                                    key.name.lowercase().replaceFirstChar { it.uppercase() },
                                    color = if (selected) Color.White else colors.onSurface,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(999.dp))
                                        .background(if (selected) colors.primary else colors.surfaceVariant)
                                        .clickable { viewModel.setGroupBy(key) }
                                        .padding(horizontal = 14.dp, vertical = 8.dp),
                                )
                            }
                        }
                        GlassButton(text = "Start Group Shuffle", onClick = { viewModel.startGroupShuffle(); onOpenNowPlaying() })
                        plan?.let { result ->
                            Text(
                                "Plan: " + result.plan.take(6).joinToString(" → "),
                                color = colors.onSurfaceVariant,
                                fontSize = 12.sp,
                            )
                        }
                    }
                }
            }
            item {
                Text("Strategies", fontWeight = FontWeight.SemiBold, fontSize = 16.sp, color = colors.onSurface, modifier = Modifier.padding(top = 4.dp))
            }
            items(viewModel.strategies, key = { it.id }) { strategy ->
                GlassSurface(
                    modifier = Modifier.fillMaxWidth().clickable { viewModel.applyStrategy(strategy.id); onOpenNowPlaying() },
                    contentPadding = 14.dp,
                ) {
                    Column {
                        Text(strategy.name, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = colors.onSurface)
                        Text(strategy.description, color = colors.onSurfaceVariant, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
