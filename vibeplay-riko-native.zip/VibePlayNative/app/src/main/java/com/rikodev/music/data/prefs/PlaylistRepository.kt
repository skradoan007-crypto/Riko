package com.rikodev.music.data.prefs

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import com.rikodev.music.data.model.Playlist
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

/** Playlists ported from playlistStore (persisted). */
@Singleton
class PlaylistRepository @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val store = context.vibeDataStore
    private val key = stringPreferencesKey("playlists_json")

    val playlists: Flow<List<Playlist>> = store.data.map { decode(it[key]) }

    suspend fun create(name: String): String {
        val id = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        mutate { it + Playlist(id, name, emptyList(), now, now) }
        return id
    }

    suspend fun rename(id: String, name: String) = mutate { list ->
        list.map { if (it.id == id) it.copy(name = name, updatedMs = System.currentTimeMillis()) else it }
    }

    suspend fun delete(id: String) = mutate { list -> list.filterNot { it.id == id } }

    suspend fun addTrack(id: String, trackId: String) = mutate { list ->
        list.map {
            if (it.id == id && trackId !in it.trackIds)
                it.copy(trackIds = it.trackIds + trackId, updatedMs = System.currentTimeMillis())
            else it
        }
    }

    suspend fun removeTrack(id: String, trackId: String) = mutate { list ->
        list.map {
            if (it.id == id)
                it.copy(trackIds = it.trackIds - trackId, updatedMs = System.currentTimeMillis())
            else it
        }
    }

    private suspend fun mutate(block: (List<Playlist>) -> List<Playlist>) {
        store.edit { prefs -> prefs[key] = encode(block(decode(prefs[key]))) }
    }

    private fun encode(list: List<Playlist>): String {
        val arr = JSONArray()
        list.forEach { p ->
            val o = JSONObject()
            o.put("id", p.id)
            o.put("name", p.name)
            o.put("trackIds", JSONArray(p.trackIds))
            o.put("createdMs", p.createdMs)
            o.put("updatedMs", p.updatedMs)
            arr.put(o)
        }
        return arr.toString()
    }

    private fun decode(raw: String?): List<Playlist> {
        if (raw.isNullOrEmpty()) return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val ids = o.getJSONArray("trackIds")
                Playlist(
                    id = o.getString("id"),
                    name = o.getString("name"),
                    trackIds = (0 until ids.length()).map { ids.getString(it) },
                    createdMs = o.optLong("createdMs"),
                    updatedMs = o.optLong("updatedMs"),
                )
            }
        }.getOrDefault(emptyList())
    }
}
