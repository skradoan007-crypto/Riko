package com.rikodev.music.data.repo

import com.rikodev.music.data.db.TrackDao
import com.rikodev.music.data.db.toEntity
import com.rikodev.music.data.db.toModel
import com.rikodev.music.data.model.DuplicateGroup
import com.rikodev.music.data.model.ScanProgress
import com.rikodev.music.data.model.Track
import com.rikodev.music.data.prefs.FavoritesRepository
import com.rikodev.music.data.prefs.HistoryRepository
import com.rikodev.music.data.scan.MediaStoreScanner
import com.rikodev.music.feature.metadata.LibraryIndexes
import com.rikodev.music.feature.metadata.buildIndexes
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Single source of truth for the full-folder-scan Library (Mode 2). Merges the
 * persisted Room rows with live favorite + play-count/history state so the UI always
 * sees enriched [Track]s. Ported from libraryStore + favoritesStore + historyStore.
 */
@Singleton
class LibraryRepository @Inject constructor(
    private val dao: TrackDao,
    private val scanner: MediaStoreScanner,
    private val favoritesRepository: FavoritesRepository,
    private val historyRepository: HistoryRepository,
) {
    private val _scanProgress = MutableStateFlow(ScanProgress())
    val scanProgress: StateFlow<ScanProgress> = _scanProgress

    /** Enriched library: Room rows decorated with favorite + play-count + last-played. */
    val library: Flow<List<Track>> = combine(
        dao.observeAll(),
        favoritesRepository.favoriteIds,
        historyRepository.history,
    ) { entities, favorites, history ->
        entities.map { e ->
            val t = e.toModel(isFavorite = favorites.contains(e.id))
            t.copy(
                playCount = history.playCounts[t.id] ?: t.playCount,
                lastPlayedMs = history.lastPlayedMs[t.id] ?: t.lastPlayedMs,
            )
        }
    }

    val indexes: Flow<LibraryIndexes> = library.map { buildIndexes(it) }

    val favorites: Flow<List<Track>> = library.map { list -> list.filter { it.isFavorite } }

    val duplicates: Flow<List<DuplicateGroup>> = dao.observeAll().map { entities ->
        entities.groupBy { it.contentHash }
            .filter { it.value.size > 1 }
            .map { (hash, rows) -> DuplicateGroup(contentHash = hash, trackIds = rows.map { it.id }) }
    }

    suspend fun rescan(excludeShortClips: Boolean, minClipSeconds: Int, deepTags: Boolean) {
        var latest: List<Track> = emptyList()
        scanner.scan(
            excludeShortClips = excludeShortClips,
            minClipSeconds = minClipSeconds,
            deepTags = deepTags,
        ).collect { (progress, tracks) ->
            _scanProgress.value = progress
            latest = tracks
        }
        dao.replaceLibrary(latest.map { it.toEntity() })
    }

    suspend fun clear() = dao.clear()

    suspend fun markPlayed(trackId: String) {
        dao.markPlayed(trackId, System.currentTimeMillis())
        historyRepository.recordPlay(trackId, System.currentTimeMillis())
    }

    suspend fun toggleFavorite(trackId: String) = favoritesRepository.toggle(trackId)
}
