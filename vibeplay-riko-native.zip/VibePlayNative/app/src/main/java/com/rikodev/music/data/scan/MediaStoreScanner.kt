package com.rikodev.music.data.scan

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import com.rikodev.music.data.model.ScanPhase
import com.rikodev.music.data.model.ScanProgress
import com.rikodev.music.data.model.Track
import com.rikodev.music.feature.metadata.parseFromFilename
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Full-device library scanner (MODE 2) — the native replacement for the
 * expo-media-library scanner. UPGRADES over the RN version:
 *   • real album / albumArtist / genre / year / track number / size from MediaStore
 *   • real album-art content URIs
 *   • optional deep ID3 enrichment via MediaMetadataRetriever (was a passthrough stub)
 * Emits ScanProgress just like the original state machine.
 */
@Singleton
class MediaStoreScanner @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val albumArtBase = Uri.parse("content://media/external/audio/albumart")

    /**
     * @param excludeShortClips drop clips shorter than [minClipSeconds] (settings).
     * @param deepTags when true, read embedded ID3 tags per file for any field MediaStore left blank.
     */
    fun scan(
        excludeShortClips: Boolean,
        minClipSeconds: Int,
        deepTags: Boolean = true,
    ): Flow<Pair<ScanProgress, List<Track>>> = flow {
        emit(ScanProgress(ScanPhase.REQUESTING) to emptyList())

        val resolver = context.contentResolver
        val collection = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ARTIST,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.YEAR,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.IS_MUSIC,
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sortOrder = "${MediaStore.Audio.Media.DATE_ADDED} DESC"

        val tracks = ArrayList<Track>()
        resolver.query(collection, projection, selection, null, sortOrder)?.use { cursor ->
            val total = cursor.count
            emit(ScanProgress(ScanPhase.SCANNING, 0, total) to emptyList())

            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val albumArtistCol = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM_ARTIST)
            val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val trackCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
            val yearCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.YEAR)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)

            var scanned = 0
            val minMs = minClipSeconds * 1000L
            while (cursor.moveToNext()) {
                scanned++
                val durationMs = cursor.getLong(durationCol)
                if (excludeShortClips && durationMs in 1 until minMs) {
                    if (scanned % 25 == 0) emit(ScanProgress(ScanPhase.SCANNING, scanned, total) to emptyList())
                    continue
                }
                val id = cursor.getLong(idCol)
                val uri = ContentUris.withAppendedId(collection, id)
                val data = cursor.getString(dataCol) ?: ""
                val filename = cursor.getString(nameCol) ?: File(data).name
                val parsed = parseFromFilename(filename)

                var title = cursor.getString(titleCol)?.takeIf { it.isNotBlank() } ?: parsed.title
                var artist = cursor.getString(artistCol)?.normalizeArtist() ?: parsed.artist ?: "Unknown Artist"
                var album = cursor.getString(albumCol)?.takeIf { it.isNotBlank() } ?: "Unknown Album"
                var albumArtist = albumArtistCol.takeIf { it >= 0 }?.let { cursor.getString(it) }
                var year = cursor.getInt(yearCol).takeIf { it > 0 }
                var genre: String? = null
                val rawTrack = cursor.getInt(trackCol)
                var trackNumber = (if (rawTrack > 1000) rawTrack % 1000 else rawTrack).takeIf { it > 0 } ?: parsed.trackNumber

                // Deep ID3 enrichment for fields MediaStore left blank (real, not a stub).
                if (deepTags && (genre == null || year == null || albumArtist == null)) {
                    runCatching {
                        MediaMetadataRetriever().use { mmr ->
                            mmr.setDataSource(context, uri)
                            genre = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE)
                                ?.takeIf { it.isNotBlank() }
                            if (year == null) {
                                mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_YEAR)
                                    ?.filter { it.isDigit() }?.takeIf { it.isNotBlank() }
                                    ?.let { year = it.toIntOrNull() }
                            }
                            if (albumArtist == null) {
                                albumArtist = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST)
                            }
                        }
                    }
                }

                val albumId = cursor.getLong(albumIdCol)
                val artworkUri = ContentUris.withAppendedId(albumArtBase, albumId).toString()
                val folderFile = File(data).parentFile
                val folderPath = folderFile?.absolutePath ?: "/"
                val folderName = folderFile?.name ?: "Music"

                tracks.add(
                    Track(
                        id = "ms:$id",
                        uri = uri.toString(),
                        filename = filename,
                        title = title,
                        artist = artist,
                        album = album,
                        albumArtist = albumArtist,
                        genre = genre,
                        mood = null,
                        durationMs = durationMs,
                        trackNumber = trackNumber,
                        year = year,
                        folderPath = folderPath,
                        folderName = folderName,
                        sizeBytes = cursor.getLong(sizeCol),
                        dateAddedMs = cursor.getLong(dateCol) * 1000L,
                        artworkUri = artworkUri,
                    ),
                )
                if (scanned % 25 == 0) emit(ScanProgress(ScanPhase.SCANNING, scanned, total) to emptyList())
            }
        }

        emit(ScanProgress(ScanPhase.INDEXING, tracks.size, tracks.size) to tracks)
        emit(ScanProgress(ScanPhase.DONE, tracks.size, tracks.size) to tracks)
    }

    private fun String.normalizeArtist(): String? {
        val v = trim()
        return if (v.isBlank() || v == "<unknown>") null else v
    }
}
