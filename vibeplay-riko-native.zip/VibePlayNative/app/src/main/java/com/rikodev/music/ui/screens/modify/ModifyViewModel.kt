package com.rikodev.music.ui.screens.modify

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rikodev.music.data.prefs.ModifyRepository
import com.rikodev.music.feature.modify.BUILT_IN_PRESETS
import com.rikodev.music.feature.modify.DspState
import com.rikodev.music.feature.modify.EQ_FREQUENCIES
import com.rikodev.music.feature.modify.EqPreset
import com.rikodev.music.feature.modify.applyPreset
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Modification Lab view model — the full native DSP control surface (10-band EQ,
 * enhancers, speed/pitch/preamp + presets). Every change is persisted and pushed live
 * to the session-bound AudioFxController via the player.
 */
@HiltViewModel
class ModifyViewModel @Inject constructor(
    private val modifyRepository: ModifyRepository,
) : ViewModel() {

    val frequencies: List<Int> = EQ_FREQUENCIES
    val presets: List<EqPreset> = BUILT_IN_PRESETS

    val dsp: StateFlow<DspState> = modifyRepository.dsp
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DspState())
    val enabled: StateFlow<Boolean> = modifyRepository.enabled
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    private fun update(transform: (DspState) -> DspState) =
        viewModelScope.launch { modifyRepository.setDsp(transform(dsp.value)) }

    fun setEnabled(value: Boolean) = viewModelScope.launch { modifyRepository.setEnabled(value) }
    fun setBand(index: Int, value: Float) = update { it.withBand(index, value) }
    fun setBassBoost(value: Float) = update { it.copy(bassBoost = value) }
    fun setTrebleBoost(value: Float) = update { it.copy(trebleBoost = value) }
    fun setVocal(value: Float) = update { it.copy(vocal = value) }
    fun setReverb(value: Float) = update { it.copy(reverb = value) }
    fun setEcho(value: Float) = update { it.copy(echo = value) }
    fun setStereoWidth(value: Float) = update { it.copy(stereoWidth = value) }
    fun setPreamp(value: Float) = update { it.copy(preamp = value) }
    fun setSpeed(value: Float) = update { it.copy(speed = value) }
    fun setPitch(value: Float) = update { it.copy(pitch = value) }
    fun applyPreset(preset: EqPreset) = update { it.applyPreset(preset) }
    fun reset() = viewModelScope.launch { modifyRepository.setDsp(DspState()) }
}
