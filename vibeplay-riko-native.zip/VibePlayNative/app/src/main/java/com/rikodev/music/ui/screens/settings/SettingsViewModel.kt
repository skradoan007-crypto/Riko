package com.rikodev.music.ui.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rikodev.music.data.prefs.AppSettings
import com.rikodev.music.data.prefs.HistoryRepository
import com.rikodev.music.data.prefs.SettingsRepository
import com.rikodev.music.data.repo.LibraryRepository
import com.rikodev.music.ui.theme.ThemeMode
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val libraryRepository: LibraryRepository,
    private val historyRepository: HistoryRepository,
) : ViewModel() {

    val settings: StateFlow<AppSettings> = settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    fun setThemeMode(mode: ThemeMode) = viewModelScope.launch { settingsRepository.setThemeMode(mode) }
    fun setAccent(color: Long) = viewModelScope.launch { settingsRepository.setAccent(color) }
    fun setAnimations(value: Boolean) = viewModelScope.launch { settingsRepository.setAnimations(value) }
    fun setGestures(value: Boolean) = viewModelScope.launch { settingsRepository.setGestures(value) }
    fun setAutoRescan(value: Boolean) = viewModelScope.launch { settingsRepository.setAutoRescan(value) }
    fun setExcludeShort(value: Boolean) = viewModelScope.launch { settingsRepository.setExcludeShort(value) }
    fun setMinClip(seconds: Int) = viewModelScope.launch { settingsRepository.setMinClip(seconds) }
    fun setResume(value: Boolean) = viewModelScope.launch { settingsRepository.setResume(value) }
    fun setGapless(value: Boolean) = viewModelScope.launch { settingsRepository.setGapless(value) }
    fun setDefaultRate(rate: Float) = viewModelScope.launch { settingsRepository.setDefaultRate(rate) }

    fun rescanLibrary() = viewModelScope.launch {
        val s = settings.value
        libraryRepository.rescan(s.excludeShortClips, s.minClipSeconds, deepTags = true)
    }

    fun clearHistory() = viewModelScope.launch { historyRepository.clear() }
}
