package com.rikodev.music.data.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.rikodev.music.data.model.Track

/**
 * Room entity replacing the hand-rolled expo-sqlite `tracks` table.
 * Indices mirror the original schema (artist/album/genre/folder/contentHash).
 * contentHash powers duplicate detection: lowercase(title|durationMs|sizeBytes).
 */
@Entity(
    tableName = "tracks",
    indices = [
        Index("artist"),
        Index("album"),
        Index("genre"),
        Index("folderPath"),
        Index("contentHash"),
    ],
)
data class TrackEntity(
    @PrimaryKey val id: String,
    val uri: String,
    val filename: String,
    val title: String,
    val artist: String,
    val album: String,
    val albumArtist: String?,
    val genre: String?,
    val mood: String?,
    val durationMs: Long,
    val trackNumber: Int?,
    val year: Int?,
    val folderPath: String,
    val folderName: String,
    val sizeBytes: Long,
    val dateAddedMs: Long,
    val artworkUri: String?,
    @ColumnInfo(defaultValue = "0") val playCount: Int,
    val lastPlayedMs: Long?,
    val contentHash: String,
)

fun TrackEntity.toModel(isFavorite: Boolean = false): Track = Track(
    id = id,
    uri = uri,
    filename = filename,
    title = title,
    artist = artist,
    album = album,
    albumArtist = albumArtist,
    genre = genre,
    mood = mood,
    durationMs = durationMs,
    trackNumber = trackNumber,
    year = year,
    folderPath = folderPath,
    folderName = folderName,
    sizeBytes = sizeBytes,
    dateAddedMs = dateAddedMs,
    artworkUri = artworkUri,
    playCount = playCount,
    lastPlayedMs = lastPlayedMs,
    isFavorite = isFavorite,
)

fun contentHashOf(title: String, durationMs: Long, sizeBytes: Long): String =
    "$title|$durationMs|$sizeBytes".lowercase()

fun Track.toEntity(): TrackEntity = TrackEntity(
    id = id,
    uri = uri,
    filename = filename,
    title = title,
    artist = artist,
    album = album,
    albumArtist = albumArtist,
    genre = genre,
    mood = mood,
    durationMs = durationMs,
    trackNumber = trackNumber,
    year = year,
    folderPath = folderPath,
    folderName = folderName,
    sizeBytes = sizeBytes,
    dateAddedMs = dateAddedMs,
    artworkUri = artworkUri,
    playCount = playCount,
    lastPlayedMs = lastPlayedMs,
    contentHash = contentHashOf(title, durationMs, sizeBytes),
)
