package com.rikodev.music.data.db

import androidx.room.Database
import androidx.room.RoomDatabase

/**
 * Room database — the native replacement for core/db (vibeplay.db, schema v1).
 * Favorites, history, playlists and settings now live in DataStore (see data/prefs).
 */
@Database(
    entities = [TrackEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun trackDao(): TrackDao

    companion object {
        const val NAME = "vibeplay.db"
    }
}
