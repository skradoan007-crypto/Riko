package com.rikodev.music.ui.screens.browse

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.LibraryAdd
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.rikodev.music.ui.components.AmbientBackground
import com.rikodev.music.ui.components.GlassButton
import com.rikodev.music.ui.components.GlassButtonVariant
import com.rikodev.music.ui.components.GlassSurface
import com.rikodev.music.ui.components.TrackRow
import com.rikodev.music.ui.theme.VibeTheme

/**
 * MODE 1 — Browse + Pick. Two ephemeral SAF workflows: open a whole folder, or pick
 * individual files. Nothing here is persisted (kept fully distinct from the Library).
 * Ported from app/(tabs)/browse.tsx.
 */
@Composable
fun BrowseScreen(
    onOpenNowPlaying: () -> Unit,
    viewModel: BrowseViewModel = hiltViewModel(),
) {
    val colors = VibeTheme.colors
    val state by viewModel.state.collectAsStateWithLifecycle()

    val folderLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree(),
    ) { uri: Uri? -> uri?.let { viewModel.openFolder(it) } }

    val filesLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments(),
    ) { uris: List<Uri> -> if (uris.isNotEmpty()) viewModel.pickFiles(uris) }

    AmbientBackground {
        Column(modifier = Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 18.dp)) {
            Text("Browse", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = colors.onSurface, modifier = Modifier.padding(vertical = 12.dp))

            GlassSurface(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Open without scanning", fontWeight = FontWeight.SemiBold, color = colors.onSurface, fontSize = 15.sp)
                    Text(
                        "Pick a folder or files to play instantly. This stays separate from your indexed Library.",
                        color = colors.onSurfaceVariant,
                        fontSize = 13.sp,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        GlassButton(
                            text = "Open folder",
                            onClick = { folderLauncher.launch(null) },
                            leading = { Icon(Icons.Filled.FolderOpen, contentDescription = null, tint = Color.White) },
                        )
                        GlassButton(
                            text = "Pick files",
                            onClick = { filesLauncher.launch(arrayOf("audio/*")) },
                            variant = GlassButtonVariant.GLASS,
                            leading = { Icon(Icons.Filled.LibraryAdd, contentDescription = null, tint = colors.onSurface) },
                        )
                    }
                }
            }

            if (state.loading) {
                Row(modifier = Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = Arrangement.Center) {
                    CircularProgressIndicator(color = colors.accent)
                }
            }

            if (state.tracks.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(state.sourceLabel, color = colors.onSurfaceVariant, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    GlassButton(
                        text = "Play all",
                        onClick = { viewModel.playAll(); onOpenNowPlaying() },
                        leading = { Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = Color.White) },
                    )
                }
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(top = 8.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 160.dp),
                ) {
                    items(state.tracks, key = { it.id }) { track ->
                        TrackRow(
                            track = track,
                            isActive = false,
                            onClick = { viewModel.play(track); onOpenNowPlaying() },
                            onToggleFavorite = { },
                        )
                    }
                }
            }
        }
    }
}
