package com.rikodev.music.ui.screens.player

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.rikodev.music.data.model.RepeatMode
import com.rikodev.music.ui.components.AmbientBackground
import com.rikodev.music.ui.components.SeekBar
import com.rikodev.music.ui.components.Visualizer
import com.rikodev.music.ui.theme.VibeTheme

/**
 * Now Playing — cinematic full player ported from app/now-playing.tsx: swipe-down to
 * dismiss, spinning neon halo + breathing artwork, the real FFT Visualizer, scrubbable
 * seek bar and the full transport (shuffle/prev/play/next/repeat) plus favorite +
 * Modification Lab access.
 */
@Composable
fun NowPlayingScreen(
    onDismiss: () -> Unit,
    onOpenModify: () -> Unit,
    viewModel: PlayerViewModel = hiltViewModel(),
) {
    val colors = VibeTheme.colors
    val state by viewModel.state.collectAsStateWithLifecycle()
    val magnitudes by viewModel.magnitudes.collectAsStateWithLifecycle()
    val track = state.current

    val transition = rememberInfiniteTransition(label = "halo")
    val angle by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(12000, easing = LinearEasing), RepeatMode.Restart),
        label = "spin",
    )

    AmbientBackground {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = 24.dp)
                .pointerInput(Unit) {
                    detectVerticalDragGestures { _, dragAmount ->
                        if (dragAmount > 22) onDismiss()
                    }
                },
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Filled.KeyboardArrowDown,
                    contentDescription = "Close",
                    tint = colors.onSurface,
                    modifier = Modifier.size(30.dp).clip(CircleShape).clickableNoRipple(onDismiss),
                )
                Text("Now Playing", modifier = Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.SemiBold, color = colors.onSurface)
                Icon(
                    Icons.Filled.Tune,
                    contentDescription = "Modify",
                    tint = colors.accent,
                    modifier = Modifier.size(26.dp).clickableNoRipple(onOpenModify),
                )
            }

            Box(modifier = Modifier.padding(top = 24.dp).size(260.dp), contentAlignment = Alignment.Center) {
                Box(
                    modifier = Modifier
                        .size(260.dp)
                        .rotate(angle)
                        .clip(CircleShape)
                        .background(Brush.sweepGradient(listOf(colors.accentCyan, colors.accentViolet, colors.accentPink, colors.accentCyan))),
                )
                Box(
                    modifier = Modifier
                        .size(220.dp)
                        .clip(RoundedCornerShape(28.dp))
                        .background(Brush.linearGradient(listOf(colors.accentCyan.copy(alpha = 0.5f), colors.accentViolet.copy(alpha = 0.5f)))),
                    contentAlignment = Alignment.Center,
                ) {
                    if (track?.artworkUri != null) {
                        AsyncImage(
                            model = track.artworkUri,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.size(220.dp).clip(RoundedCornerShape(28.dp)),
                        )
                    } else {
                        Icon(Icons.Filled.MusicNote, contentDescription = null, tint = colors.onPrimary, modifier = Modifier.size(80.dp))
                    }
                }
            }

            Text(
                track?.title ?: "Nothing playing",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = colors.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 26.dp),
            )
            Text(track?.artist ?: "—", fontSize = 15.sp, color = colors.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)

            Visualizer(magnitudes = magnitudes, modifier = Modifier.padding(top = 18.dp), height = 90.dp)

            SeekBar(
                positionMs = state.positionMs,
                durationMs = state.durationMs,
                onSeek = viewModel::seekTo,
                modifier = Modifier.padding(top = 10.dp),
            )

            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 14.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    Icons.Filled.Shuffle,
                    contentDescription = "Shuffle",
                    tint = if (state.shuffleOn) colors.accent else colors.onSurfaceVariant,
                    modifier = Modifier.size(26.dp).clickableNoRipple(viewModel::toggleShuffle),
                )
                Icon(
                    Icons.Filled.SkipPrevious,
                    contentDescription = "Previous",
                    tint = colors.onSurface,
                    modifier = Modifier.size(40.dp).clickableNoRipple(viewModel::previous),
                )
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(colors.primary, colors.accent)))
                        .clickableNoRipple(viewModel::toggle),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        if (state.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = "Play/Pause",
                        tint = Color.White,
                        modifier = Modifier.size(38.dp),
                    )
                }
                Icon(
                    Icons.Filled.SkipNext,
                    contentDescription = "Next",
                    tint = colors.onSurface,
                    modifier = Modifier.size(40.dp).clickableNoRipple(viewModel::next),
                )
                Icon(
                    if (state.repeat == RepeatMode.ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                    contentDescription = "Repeat",
                    tint = if (state.repeat == RepeatMode.OFF) colors.onSurfaceVariant else colors.accent,
                    modifier = Modifier.size(26.dp).clickableNoRipple(viewModel::cycleRepeat),
                )
            }

            Row(modifier = Modifier.fillMaxWidth().padding(top = 18.dp), horizontalArrangement = Arrangement.Center) {
                Icon(
                    if (track?.isFavorite == true) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    contentDescription = "Favorite",
                    tint = if (track?.isFavorite == true) colors.accentPink else colors.onSurfaceVariant,
                    modifier = Modifier.size(28.dp).clickableNoRipple(viewModel::toggleFavoriteCurrent),
                )
            }
        }
    }
}

private fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier =
    this.then(
        androidx.compose.foundation.clickable(
            interactionSource = androidx.compose.foundation.interaction.MutableInteractionSource(),
            indication = null,
        ) { onClick() },
    )
