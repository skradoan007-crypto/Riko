package com.rikodev.music.ui.theme

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** Spacing / radius / motion tokens ported from theme/tokens.ts. */
object Spacing {
    val xs = 4.dp
    val sm = 8.dp
    val md = 12.dp
    val lg = 16.dp
    val xl = 24.dp
    val xxl = 32.dp
    val xxxl = 48.dp
}

object Radius {
    val sm = 12.dp
    val md = 18.dp
    val lg = 24.dp
    val xl = 32.dp
    val pill = 999.dp
}

object Motion {
    const val FAST = 180
    const val BASE = 280
    const val SLOW = 460
    // Springy press feel used across the UI (PressableScale / GlassButton).
    val DampingRatio = 0.62f
    val Stiffness = Spring.StiffnessMediumLow
}

fun <T> vibeSpring() = spring<T>(
    dampingRatio = Motion.DampingRatio,
    stiffness = Motion.Stiffness,
)

/** Glass tokens ported from theme/glass.ts (fills, borders, glows). */
object Glass {
    val blurBase = 36
    val blurStrong = 60

    // Light mode frosted fills.
    val fillLight = Color(0x8CFFFFFF)   // rgba(255,255,255,0.55)
    val fillMid = Color(0x61FFFFFF)     // 0.38
    val fillFaint = Color(0x3DFFFFFF)   // 0.24

    // AMOLED frosted fills.
    val fillLightAmoled = Color(0xB30A0E14)
    val fillMidAmoled = Color(0x8C141A24)
    val fillFaintAmoled = Color(0x66141A24)

    val borderLight = Color(0x40FFFFFF)
    val borderAccent = Color(0x6600E5FF)
    val borderLightAmoled = Color(0x1FFFFFFF)

    val glowPrimary = Color(0x331565C0)
    val glowCyan = Color(0x3300E5FF)
    val glowPink = Color(0x33FF4D8D)
}
