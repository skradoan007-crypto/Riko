package com.rikodev.music.feature.metadata

import com.rikodev.music.data.model.Album
import com.rikodev.music.data.model.Artist
import com.rikodev.music.data.model.FolderNode
import com.rikodev.music.data.model.Genre
import com.rikodev.music.data.model.Track

/** Aggregated browse indexes ported from core/metadata/aggregate.ts. */
data class LibraryIndexes(
    val artists: List<Artist>,
    val albums: List<Album>,
    val genres: List<Genre>,
    val folders: List<FolderNode>,
)

fun buildIndexes(tracks: List<Track>): LibraryIndexes {
    val artistCounts = LinkedHashMap<String, Int>()
    val albumKeys = LinkedHashMap<String, Pair<String, String>>() // key -> (album, artist)
    val albumCounts = LinkedHashMap<String, Int>()
    val albumArt = HashMap<String, String?>()
    val genreCounts = LinkedHashMap<String, Int>()
    val folderCounts = LinkedHashMap<String, Int>()
    val folderNames = HashMap<String, String>()

    for (t in tracks) {
        artistCounts[t.artist] = (artistCounts[t.artist] ?: 0) + 1
        val aKey = "${t.album}\u0000${t.albumArtist ?: t.artist}"
        albumKeys[aKey] = t.album to (t.albumArtist ?: t.artist)
        albumCounts[aKey] = (albumCounts[aKey] ?: 0) + 1
        if (albumArt[aKey] == null) albumArt[aKey] = t.artworkUri
        t.genre?.takeIf { it.isNotBlank() }?.let { g ->
            genreCounts[g] = (genreCounts[g] ?: 0) + 1
        }
        folderCounts[t.folderPath] = (folderCounts[t.folderPath] ?: 0) + 1
        folderNames[t.folderPath] = t.folderName
    }

    val artists = artistCounts.entries.map { Artist(it.key, it.key, it.value) }
        .sortedBy { it.name.lowercase() }
    val albums = albumKeys.entries.map { (key, pair) ->
        Album(key, pair.first, pair.second, albumCounts[key] ?: 0, albumArt[key])
    }.sortedBy { it.name.lowercase() }
    val genres = genreCounts.entries.map { Genre(it.key, it.key, it.value) }
        .sortedBy { it.name.lowercase() }
    val folders = folderCounts.entries.map { FolderNode(it.key, folderNames[it.key] ?: it.key, it.value) }
        .sortedBy { it.name.lowercase() }

    return LibraryIndexes(artists, albums, genres, folders)
}
