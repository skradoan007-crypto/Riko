package com.rikodev.music.ui.screens.library

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rikodev.music.audio.PlayerController
import com.rikodev.music.data.model.DuplicateGroup
import com.rikodev.music.data.model.ScanProgress
import com.rikodev.music.data.model.Track
import com.rikodev.music.data.prefs.SettingsRepository
import com.rikodev.music.data.repo.LibraryRepository
import com.rikodev.music.feature.metadata.LibraryIndexes
import com.rikodev.music.feature.search.searchLibrary
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class LibraryUiState(
    val tracks: List<Track> = emptyList(),
    val indexes: LibraryIndexes = LibraryIndexes(emptyList(), emptyList(), emptyList(), emptyList()),
    val duplicates: List<DuplicateGroup> = emptyList(),
    val query: String = "",
)

@HiltViewModel
class LibraryViewModel @Inject constructor(
    private val libraryRepository: LibraryRepository,
    private val settingsRepository: SettingsRepository,
    private val playerController: PlayerController,
) : ViewModel() {

    private val query = MutableStateFlow("")

    val scanProgress: StateFlow<ScanProgress> = libraryRepository.scanProgress

    val uiState: StateFlow<LibraryUiState> = combine(
        libraryRepository.library,
        libraryRepository.indexes,
        libraryRepository.duplicates,
        query,
    ) { tracks, indexes, duplicates, q ->
        val filtered = if (q.isBlank()) tracks else searchLibrary(tracks, q).tracks
        LibraryUiState(tracks = filtered, indexes = indexes, duplicates = duplicates, query = q)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), LibraryUiState())

    init {
        viewModelScope.launch {
            val settings = settingsRepository.settings
            // Auto-rescan on launch when enabled.
            settings.collect { s ->
                if (s.autoRescanOnLaunch && libraryRepository.scanProgress.value.scanned == 0) {
                    rescan()
                }
                return@collect
            }
        }
    }

    fun setQuery(value: String) { query.value = value }

    fun rescan() {
        viewModelScope.launch {
            val s = settingsRepositorySettings()
            libraryRepository.rescan(s.first, s.second, deepTags = true)
        }
    }

    private suspend fun settingsRepositorySettings(): Pair<Boolean, Int> {
        var exclude = true
        var minSec = 30
        settingsRepository.settings.collect {
            exclude = it.excludeShortClips
            minSec = it.minClipSeconds
            return@collect
        }
        return exclude to minSec
    }

    fun play(track: Track) {
        val list = uiState.value.tracks
        val index = list.indexOfFirst { it.id == track.id }.coerceAtLeast(0)
        playerController.setQueueAndPlay(list, index)
        viewModelScope.launch { libraryRepository.markPlayed(track.id) }
    }

    fun toggleFavorite(track: Track) {
        viewModelScope.launch { libraryRepository.toggleFavorite(track.id) }
    }

    fun clearLibrary() { viewModelScope.launch { libraryRepository.clear() } }
}
